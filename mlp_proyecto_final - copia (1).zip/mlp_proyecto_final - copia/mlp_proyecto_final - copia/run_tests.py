"""
Script para ejecutar todas las pruebas unitarias
"""
import sys
import os

# Agregar el directorio raíz al path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

import subprocess


def main():
    """Ejecuta todas las pruebas"""
    print("=" * 60)
    print("EJECUTANDO PRUEBAS UNITARIAS")
    print("=" * 60 + "\n")
    
    test_files = [
        'tests/test_mlp.py',
        'tests/test_selection.py',
    ]
    
    for test_file in test_files:
        if os.path.exists(test_file):
            print(f"\nEjecutando {test_file}...")
            print("-" * 60)
            try:
                result = subprocess.run(
                    [sys.executable, test_file],
                    capture_output=False,
                    text=True
                )
                if result.returncode != 0:
                    print(f"[WARN] Algunas pruebas fallaron en {test_file}")
            except Exception as e:
                print(f"Error ejecutando {test_file}: {e}")
        else:
            print(f"[WARN] Archivo no encontrado: {test_file}")
    
    print("\n" + "=" * 60)
    print("PRUEBAS COMPLETADAS")
    print("=" * 60)


if __name__ == "__main__":
    main()

