"""
Script para ejecutar y entrenar la red neuronal base del proyecto
"""
import numpy as np
from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data


def main():
    print("=" * 70)
    print("ENTRENAMIENTO DE RED NEURONAL MLP DESDE CERO")
    print("=" * 70)
    
    # Configuración
    print("\n[1/5] Configurando parámetros...")
    config = {
        'n_samples': 1000,
        'n_features': 50,
        'n_classes': 5,
        'test_size': 0.2,
        'input_size': 50,
        'hidden_size': 30,
        'output_size': 5,
        'activation': 'sigmoid',
        'learning_rate': 0.01,
        'epochs': 30,
        'batch_size': 32,
        'seed': 42
    }
    
    print(f"  • Muestras: {config['n_samples']}")
    print(f"  • Características: {config['n_features']}")
    print(f"  • Clases: {config['n_classes']}")
    print(f"  • Arquitectura: {config['input_size']} → {config['hidden_size']} → {config['output_size']}")
    print(f"  • Activación: {config['activation']}")
    print(f"  • Tasa de aprendizaje: {config['learning_rate']}")
    print(f"  • Épocas: {config['epochs']}")
    print(f"  • Batch size: {config['batch_size']}")
    
    # Generar datos
    print("\n[2/5] Generando datos sintéticos...")
    np.random.seed(config['seed'])
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=config['n_samples'],
        n_features=config['n_features'],
        n_classes=config['n_classes'],
        test_size=config['test_size']
    )
    print(f"  • Datos entrenamiento: {X_train.data.shape}")
    print(f"  • Datos prueba: {X_test.data.shape}")
    
    # Crear modelo
    print("\n[3/5] Creando modelo MLP...")
    mlp = MLP(
        input_size=config['input_size'],
        hidden_size=config['hidden_size'],
        output_size=config['output_size'],
        activation=config['activation'],
        learning_rate=config['learning_rate'],
        seed=config['seed']
    )
    print(f"  ✓ Modelo creado exitosamente")
    
    # Entrenar
    print("\n[4/5] Entrenando modelo...")
    print("-" * 70)
    history = mlp.train(
        X_train, y_train,
        epochs=config['epochs'],
        batch_size=config['batch_size'],
        X_val=X_test,
        y_val=y_test,
        verbose=True
    )
    print("-" * 70)
    
    # Evaluar
    print("\n[5/5] Evaluando modelo...")
    train_accuracy = mlp.evaluate(X_train, y_train)
    test_accuracy = mlp.evaluate(X_test, y_test)
    
    print(f"  • Precisión entrenamiento: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"  • Precisión prueba: {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    
    # Resumen
    print("\n" + "=" * 70)
    print("RESUMEN DEL ENTRENAMIENTO")
    print("=" * 70)
    print(f"Pérdida inicial: {history[0]['loss']:.6f}")
    print(f"Pérdida final: {history[-1]['loss']:.6f}")
    print(f"Reducción de pérdida: {((history[0]['loss'] - history[-1]['loss']) / history[0]['loss'] * 100):.2f}%")
    print(f"\nPrecisión final en validación: {history[-1]['val_accuracy']:.4f}")
    print("=" * 70)


if __name__ == "__main__":
    main()
