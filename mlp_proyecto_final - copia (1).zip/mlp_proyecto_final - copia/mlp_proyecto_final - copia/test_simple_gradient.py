"""
Prueba simple de un solo parámetro para verificar el cálculo
"""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix

# Modelo muy simple
mlp = MLP(input_size=2, hidden_size=1, output_size=2, seed=42)
X = Matrix(np.array([[1.0, 2.0]]))
y = Matrix(np.array([0]))

print("Pesos originales:")
print(f"W2[0,0] = {mlp.W2.data[0,0]}")

# Forward y backward
z1, a1, a2 = mlp.forward(X)
dW1, db1, dW2, db2 = mlp.backward(X, y, z1, a1, a2)

print(f"\nGradiente analitico dW2[0,0] = {dW2.data[0,0]}")

# Gradiente numérico
epsilon = 1e-7
loss_orig = mlp.loss_fn(a2, y)

# Perturbar W2[0,0]
mlp.W2.data[0, 0] += epsilon
z1_p, a1_p, a2_p = mlp.forward(X)
loss_plus = mlp.loss_fn(a2_p, y)

mlp.W2.data[0, 0] -= 2 * epsilon
z1_m, a1_m, a2_m = mlp.forward(X)
loss_minus = mlp.loss_fn(a2_m, y)

grad_numerical = (loss_plus - loss_minus) / (2 * epsilon)

print(f"Gradiente numerico dW2[0,0] = {grad_numerical}")
print(f"Diferencia: {abs(dW2.data[0,0] - grad_numerical)}")
print(f"Error relativo: {abs(dW2.data[0,0] - grad_numerical) / (abs(dW2.data[0,0]) + abs(grad_numerical) + 1e-10)}")

# Restaurar
mlp.W2.data[0, 0] += epsilon

