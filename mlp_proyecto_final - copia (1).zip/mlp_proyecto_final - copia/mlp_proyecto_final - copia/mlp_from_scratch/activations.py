"""
Funciones de activación y sus derivadas
Análisis de complejidad: todas son O(n) donde n es el número de elementos
"""
import numpy as np
from mlp_from_scratch.matrix import Matrix


def sigmoid(x: Matrix) -> Matrix:
    """
    Función sigmoide: σ(x) = 1 / (1 + e^(-x))
    
    Complejidad temporal: O(n) donde n es el número de elementos
    Complejidad espacial: O(n) para el resultado
    """
    # Evitar overflow
    x_data = np.clip(x.data, -500, 500)
    return Matrix(1.0 / (1.0 + np.exp(-x_data)))


def sigmoid_derivative(x: Matrix) -> Matrix:
    """
    Derivada de sigmoide: σ'(x) = σ(x) * (1 - σ(x))
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    s = sigmoid(x)
    return Matrix(s.data * (1 - s.data))


def relu(x: Matrix) -> Matrix:
    """
    ReLU: max(0, x)
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    return Matrix(np.maximum(0, x.data))


def relu_derivative(x: Matrix) -> Matrix:
    """
    Derivada de ReLU: 1 si x > 0, 0 en otro caso
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    return Matrix((x.data > 0).astype(np.float64))


def tanh(x: Matrix) -> Matrix:
    """
    Tangente hiperbólica
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    return Matrix(np.tanh(x.data))


def tanh_derivative(x: Matrix) -> Matrix:
    """
    Derivada de tanh: 1 - tanh²(x)
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    t = tanh(x)
    return Matrix(1 - t.data ** 2)


def softmax(x: Matrix) -> Matrix:
    """
    Softmax para clasificación multiclase
    
    Complejidad temporal: O(n) donde n es el número de clases
    Complejidad espacial: O(n)
    """
    # Estabilidad numérica: restar el máximo
    exp_x = np.exp(x.data - np.max(x.data, axis=-1, keepdims=True))
    return Matrix(exp_x / np.sum(exp_x, axis=-1, keepdims=True))


def softmax_derivative(x: Matrix) -> Matrix:
    """
    Derivada de softmax (usada en backprop)
    Nota: En práctica, se combina con la pérdida de entropía cruzada
    
    Complejidad temporal: O(n²) en el caso general
    Complejidad espacial: O(n²)
    """
    s = softmax(x)
    # Jacobiano de softmax
    return Matrix(s.data * (1 - s.data))


# Mapeo de funciones de activación
ACTIVATIONS = {
    'sigmoid': (sigmoid, sigmoid_derivative),
    'relu': (relu, relu_derivative),
    'tanh': (tanh, tanh_derivative),
    'softmax': (softmax, softmax_derivative),
}

