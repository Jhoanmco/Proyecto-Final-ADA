"""
Funciones de pérdida y sus derivadas
"""
import numpy as np
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.activations import softmax


def mse_loss(y_pred: Matrix, y_true: Matrix) -> float:
    """
    Mean Squared Error
    
    Complejidad temporal: O(n) donde n es el número de muestras
    Complejidad espacial: O(1)
    """
    return float(np.mean((y_pred.data - y_true.data) ** 2))


def mse_derivative(y_pred: Matrix, y_true: Matrix) -> Matrix:
    """
    Derivada de MSE respecto a y_pred
    
    Complejidad temporal: O(n)
    Complejidad espacial: O(n)
    """
    n = y_pred.data.shape[0]
    return Matrix(2.0 * (y_pred.data - y_true.data) / n)


def cross_entropy_loss(y_pred: Matrix, y_true: Matrix) -> float:
    """
    Cross-Entropy Loss (para clasificación)
    
    Complejidad temporal: O(n*c) donde n es muestras y c es clases
    Complejidad espacial: O(1)
    """
    # Evitar log(0)
    epsilon = 1e-15
    y_pred_clipped = np.clip(y_pred.data, epsilon, 1 - epsilon)
    
    # y_true puede ser one-hot o índices
    if y_true.data.ndim == 1:
        # Índices de clase
        n = y_true.data.shape[0]
        loss = -np.sum(np.log(y_pred_clipped[np.arange(n), y_true.data.astype(int)])) / n
    else:
        # One-hot encoding
        loss = -np.mean(np.sum(y_true.data * np.log(y_pred_clipped), axis=1))
    
    return float(loss)


def cross_entropy_derivative(y_pred: Matrix, y_true: Matrix) -> Matrix:
    """
    Derivada de Cross-Entropy (combinada con softmax)
    
    NOTA: Esta función NO divide por el batch_size. La división se hace en backward().
    
    Complejidad temporal: O(n*c)
    Complejidad espacial: O(n*c)
    """
    n = y_pred.data.shape[0]
    
    if y_true.data.ndim == 1:
        # Índices de clase: dL/dz = y_pred - one_hot(y_true)
        grad = y_pred.data.copy()
        grad[np.arange(n), y_true.data.astype(int)] -= 1
        # NO dividir por n aquí, se divide en backward()
    else:
        # One-hot encoding: dL/dz = y_pred - y_true
        grad = y_pred.data - y_true.data
        # NO dividir por n aquí, se divide en backward()
    
    return Matrix(grad)


# Mapeo de funciones de pérdida
LOSSES = {
    'mse': (mse_loss, mse_derivative),
    'cross_entropy': (cross_entropy_loss, cross_entropy_derivative),
}

