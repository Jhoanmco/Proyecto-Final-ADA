"""
Implementación del Perceptrón Multicapa (MLP) desde cero
Incluye forward propagation, backpropagation y SGD
"""
import numpy as np
from typing import List, Tuple, Optional, Dict
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.activations import ACTIVATIONS
from mlp_from_scratch.activations import softmax
from mlp_from_scratch.losses import LOSSES


class MLP:
    """
    Perceptrón Multicapa implementado desde cero
    
    Complejidad temporal por época:
    - Forward: O(B * (n*h + h*c)) donde B=batch_size, n=input_size, h=hidden_size, c=output_size
    - Backward: O(B * (n*h + h*c))
    - Total por época: O(E * B * (n*h + h*c)) donde E=número de épocas
    
    Complejidad espacial:
    - Pesos: O(n*h + h*c)
    - Activaciones almacenadas: O(B * (n + h + c))
    - Gradientes: O(n*h + h*c)
    """
    
    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        output_size: int,
        activation: str = 'sigmoid',
        loss: str = 'cross_entropy',
        learning_rate: float = 0.001,
        seed: Optional[int] = None
    ):
        """
        Inicializa el MLP
        
        Args:
            input_size: Tamaño de la entrada
            hidden_size: Tamaño de la capa oculta
            output_size: Tamaño de la salida (número de clases)
            activation: Función de activación ('sigmoid', 'relu', 'tanh')
            loss: Función de pérdida ('mse', 'cross_entropy')
            learning_rate: Tasa de aprendizaje
            seed: Semilla para reproducibilidad
        """
        if seed is not None:
            np.random.seed(seed)
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate
        
        # Funciones de activación
        self.activation_fn, self.activation_derivative = ACTIVATIONS[activation]
        self.loss_fn, self.loss_derivative = LOSSES[loss]
        
        # Inicialización de pesos mejorada
        # Para sigmoid/tanh: Xavier/Glorot uniforme
        # Para ReLU: He initialization
        if activation in ['sigmoid', 'tanh']:
            # Xavier/Glorot uniform initialization
            limit1 = np.sqrt(6.0 / (input_size + hidden_size))
            limit2 = np.sqrt(6.0 / (hidden_size + output_size))
        elif activation == 'relu':
            # He initialization para ReLU
            limit1 = np.sqrt(2.0 / input_size)
            limit2 = np.sqrt(2.0 / hidden_size)
        else:
            # Default: Xavier
            limit1 = np.sqrt(1.0 / input_size)
            limit2 = np.sqrt(1.0 / hidden_size)
        
        # W1: input_size x hidden_size
        self.W1 = Matrix.random((input_size, hidden_size), scale=limit1)
        self.b1 = Matrix.zeros((1, hidden_size))
        
        # W2: hidden_size x output_size
        self.W2 = Matrix.random((hidden_size, output_size), scale=limit2)
        self.b2 = Matrix.zeros((1, output_size))
        
        # Historial para análisis
        self.training_history: List[Dict] = []
    
    def forward(self, X: Matrix) -> Tuple[Matrix, Matrix, Matrix]:
        """
        Forward propagation
        
        Complejidad temporal: O(B * (n*h + h*c))
        donde B=batch_size, n=input_size, h=hidden_size, c=output_size
        
        Complejidad espacial: O(B * (n + h + c)) para almacenar activaciones
        
        Returns:
            z1: Salida de la capa oculta (antes de activación)
            a1: Salida de la capa oculta (después de activación)
            a2: Salida de la capa de salida
        """
        # Capa oculta: z1 = X * W1 + b1
        # O(B * n * h) tiempo, O(B * h) espacio
        z1 = X.dot(self.W1) + self.b1
        a1 = self.activation_fn(z1)  # O(B * h)
        
        # Capa de salida: z2 = a1 * W2 + b2
        # O(B * h * c) tiempo, O(B * c) espacio
        z2 = a1.dot(self.W2) + self.b2
        
        # Para clasificación, usar softmax
        if self.output_size > 1:
            a2 = Matrix(softmax(z2).data)
        else:
            a2 = self.activation_fn(z2)
        
        return z1, a1, a2
    
    def backward(
        self,
        X: Matrix,
        y: Matrix,
        z1: Matrix,
        a1: Matrix,
        a2: Matrix
    ) -> Tuple[Matrix, Matrix, Matrix, Matrix]:
        """
        Backward propagation (gradiente descendente)
        
        Complejidad temporal: O(B * (n*h + h*c))
        Complejidad espacial: O(n*h + h*c) para los gradientes
        
        Returns:
            dW1, db1, dW2, db2: Gradientes de los pesos y sesgos
        """
        m = X.data.shape[0]  # batch_size
        
        # Gradiente de la pérdida respecto a la salida
        # Para cross-entropy + softmax: dz2 = (y_pred - y_true)
        # O(B * c)
        dz2 = self.loss_derivative(a2, y)
        
        # Gradientes de la capa de salida
        # O(B * h * c) para el producto matricial
        # Promediar sobre el batch: dW2 = (1/m) * a1^T · dz2
        dW2 = a1.T().dot(dz2) / m  # O(h * c)
        db2_sum = dz2.sum(axis=0)  # O(c)
        if isinstance(db2_sum, Matrix):
            db2 = Matrix(db2_sum.data.reshape(1, -1) / m)
        else:
            if db2_sum.ndim == 0:
                db2 = Matrix(np.array([db2_sum]).reshape(1, -1) / m)
            else:
                db2 = Matrix(db2_sum.reshape(1, -1) / m)
        
        # Propagación hacia atrás a través de la activación
        # O(B * h * c)
        da1 = dz2.dot(self.W2.T())
        
        # Gradiente a través de la activación de la capa oculta
        # O(B * h)
        dz1 = Matrix(da1.data * self.activation_derivative(z1).data)
        
        # Gradientes de la capa oculta
        # O(B * n * h)
        # Promediar sobre el batch: dW1 = (1/m) * X^T · dz1
        dW1 = X.T().dot(dz1) / m  # O(n * h)
        db1_sum = dz1.sum(axis=0)  # O(h)
        if isinstance(db1_sum, Matrix):
            db1 = Matrix(db1_sum.data.reshape(1, -1) / m)
        else:
            if db1_sum.ndim == 0:
                db1 = Matrix(np.array([db1_sum]).reshape(1, -1) / m)
            else:
                db1 = Matrix(db1_sum.reshape(1, -1) / m)
        
        return dW1, db1, dW2, db2
    
    def update_weights(
        self,
        dW1: Matrix,
        db1: Matrix,
        dW2: Matrix,
        db2: Matrix
    ):
        """
        Actualización de pesos usando SGD
        
        Complejidad temporal: O(n*h + h*c)
        Complejidad espacial: O(1) - actualización in-place
        """
        self.W1 = Matrix(self.W1.data - self.learning_rate * dW1.data)
        self.b1 = Matrix(self.b1.data - self.learning_rate * db1.data)
        self.W2 = Matrix(self.W2.data - self.learning_rate * dW2.data)
        self.b2 = Matrix(self.b2.data - self.learning_rate * db2.data)
    
    def train(
        self,
        X: Matrix,
        y: Matrix,
        epochs: int,
        batch_size: int,
        X_val: Optional[Matrix] = None,
        y_val: Optional[Matrix] = None,
        verbose: bool = True
    ) -> List[Dict]:
        """
        Entrenamiento del MLP
        
        Complejidad temporal total: O(E * (N/B) * B * (n*h + h*c))
        = O(E * N * (n*h + h*c))
        donde E=épocas, N=número total de muestras, B=batch_size
        
        Complejidad espacial: O(B * (n + h + c)) durante el entrenamiento
        
        Args:
            X: Datos de entrenamiento (N x input_size)
            y: Etiquetas (N x output_size o N)
            epochs: Número de épocas
            batch_size: Tamaño del lote
            X_val: Datos de validación (opcional)
            y_val: Etiquetas de validación (opcional)
            verbose: Mostrar progreso
        
        Returns:
            Historial de entrenamiento
        """
        N = X.data.shape[0]
        n_batches = (N + batch_size - 1) // batch_size
        
        history = []
        
        for epoch in range(epochs):
            # Mezclar datos
            indices = np.random.permutation(N)
            X_shuffled = Matrix(X.data[indices])
            y_shuffled = Matrix(y.data[indices] if y.data.ndim > 1 else y.data[indices])
            
            epoch_loss = 0.0
            
            # Entrenar por lotes
            for i in range(n_batches):
                start_idx = i * batch_size
                end_idx = min(start_idx + batch_size, N)
                
                X_batch = Matrix(X_shuffled.data[start_idx:end_idx])
                y_batch = Matrix(y_shuffled.data[start_idx:end_idx] if y_shuffled.data.ndim > 1 
                                else y_shuffled.data[start_idx:end_idx])
                
                # Forward pass
                z1, a1, a2 = self.forward(X_batch)
                
                # Calcular pérdida
                loss = self.loss_fn(a2, y_batch)
                epoch_loss += loss
                
                # Backward pass
                dW1, db1, dW2, db2 = self.backward(X_batch, y_batch, z1, a1, a2)
                
                # Actualizar pesos
                self.update_weights(dW1, db1, dW2, db2)
            
            avg_loss = epoch_loss / n_batches
            
            # Evaluación
            metrics = {'epoch': epoch + 1, 'loss': avg_loss}
            
            if X_val is not None and y_val is not None:
                val_acc = self.evaluate(X_val, y_val)
                metrics['val_accuracy'] = val_acc
            
            history.append(metrics)
            
            if verbose and (epoch + 1) % 10 == 0:
                print(f"Época {epoch + 1}/{epochs}, Pérdida: {avg_loss:.4f}", end="")
                if 'val_accuracy' in metrics:
                    print(f", Precisión validación: {val_acc:.4f}")
                else:
                    print()
        
        self.training_history = history
        return history
    
    def predict(self, X: Matrix) -> Matrix:
        """
        Predicción
        
        Complejidad temporal: O(B * (n*h + h*c))
        Complejidad espacial: O(B * c)
        """
        _, _, a2 = self.forward(X)
        return a2
    
    def evaluate(self, X: Matrix, y: Matrix) -> float:
        """
        Evalúa la precisión del modelo
        
        Complejidad temporal: O(N * (n*h + h*c))
        Complejidad espacial: O(N * c)
        """
        predictions = self.predict(X)
        
        if y.data.ndim == 1:
            # Índices de clase
            y_pred = np.argmax(predictions.data, axis=1)
            accuracy = np.mean(y_pred == y.data)
        else:
            # One-hot
            y_pred = np.argmax(predictions.data, axis=1)
            y_true = np.argmax(y.data, axis=1)
            accuracy = np.mean(y_pred == y_true)
        
        return float(accuracy)

