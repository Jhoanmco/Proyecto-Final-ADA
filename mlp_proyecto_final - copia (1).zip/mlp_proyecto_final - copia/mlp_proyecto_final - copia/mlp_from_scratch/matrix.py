"""
Implementación de operaciones matriciales básicas
Permite trabajar sin NumPy si es necesario, pero usa NumPy para eficiencia
"""
import numpy as np
from typing import List, Tuple, Optional


class Matrix:
    """
    Wrapper para operaciones matriciales con análisis de complejidad
    """
    
    def __init__(self, data: np.ndarray):
        """
        Inicializa una matriz desde un array de NumPy
        
        Complejidad temporal: O(1) - solo referencia
        Complejidad espacial: O(n*m) donde n*m es el tamaño de la matriz
        """
        self.data = np.array(data, dtype=np.float64)
        self.shape = self.data.shape
    
    @classmethod
    def zeros(cls, shape: Tuple[int, ...]) -> 'Matrix':
        """Crea matriz de ceros. O(n*m) tiempo y espacio"""
        return cls(np.zeros(shape))
    
    @classmethod
    def random(cls, shape: Tuple[int, ...], scale: float = 0.1) -> 'Matrix':
        """Crea matriz aleatoria. O(n*m) tiempo y espacio"""
        return cls(np.random.randn(*shape) * scale)
    
    def __add__(self, other: 'Matrix') -> 'Matrix':
        """
        Suma de matrices
        
        Complejidad temporal: O(n*m) donde n*m es el tamaño de la matriz
        Complejidad espacial: O(n*m) para la matriz resultado
        """
        return Matrix(self.data + other.data)
    
    def __sub__(self, other: 'Matrix') -> 'Matrix':
        """Resta de matrices. O(n*m) tiempo y espacio"""
        return Matrix(self.data - other.data)
    
    def __mul__(self, other) -> 'Matrix':
        """
        Multiplicación elemento a elemento o escalar
        
        Complejidad temporal: O(n*m) para elemento a elemento, O(1) para escalar
        Complejidad espacial: O(n*m)
        """
        if isinstance(other, (int, float)):
            return Matrix(self.data * other)
        return Matrix(self.data * other.data)
    
    def __truediv__(self, other) -> 'Matrix':
        """
        División por escalar
        
        Complejidad temporal: O(n*m)
        Complejidad espacial: O(n*m)
        """
        if isinstance(other, (int, float)):
            return Matrix(self.data / other)
        return Matrix(self.data / other.data)
    
    def __rtruediv__(self, other) -> 'Matrix':
        """División escalar / matriz (no común, pero para completitud)"""
        if isinstance(other, (int, float)):
            return Matrix(other / self.data)
        return Matrix(other.data / self.data)
    
    def dot(self, other: 'Matrix') -> 'Matrix':
        """
        Multiplicación matricial
        
        Complejidad temporal: O(n*m*p) donde A es n×m y B es m×p
        Complejidad espacial: O(n*p) para la matriz resultado
        """
        return Matrix(self.data @ other.data)
    
    def T(self) -> 'Matrix':
        """
        Transpuesta
        
        Complejidad temporal: O(n*m) - copia de datos
        Complejidad espacial: O(n*m)
        """
        return Matrix(self.data.T)
    
    def sum(self, axis: Optional[int] = None) -> 'Matrix':
        """Suma a lo largo de un eje. O(n*m) tiempo, O(1) o O(n) espacio según axis"""
        result = np.sum(self.data, axis=axis)
        if result.ndim == 0:
            return result
        return Matrix(result)
    
    def mean(self, axis: Optional[int] = None) -> 'Matrix':
        """Promedio a lo largo de un eje. O(n*m) tiempo"""
        result = np.mean(self.data, axis=axis)
        if result.ndim == 0:
            return result
        return Matrix(result)
    
    def __getitem__(self, key):
        """Acceso a elementos. O(1) tiempo"""
        return self.data[key]
    
    def __setitem__(self, key, value):
        """Asignación de elementos. O(1) tiempo"""
        self.data[key] = value
    
    def copy(self) -> 'Matrix':
        """Copia de la matriz. O(n*m) tiempo y espacio"""
        return Matrix(self.data.copy())
    
    def flatten(self) -> 'Matrix':
        """Aplana la matriz. O(n*m) tiempo y espacio"""
        return Matrix(self.data.flatten())
    
    def reshape(self, shape: Tuple[int, ...]) -> 'Matrix':
        """Reforma la matriz. O(1) tiempo si no hay copia, O(n*m) espacio"""
        return Matrix(self.data.reshape(shape))

