"""
Utilidades: verificación de gradientes, carga de datos, etc.
"""
import numpy as np
from typing import Tuple, Optional
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.mlp import MLP


def numerical_gradient(
    model: MLP,
    X: Matrix,
    y: Matrix,
    epsilon: float = 1e-7
) -> Tuple[Matrix, Matrix, Matrix, Matrix]:
    """
    Verificación numérica de gradientes (gradient checking)
    
    Complejidad temporal: O(P * B * (n*h + h*c))
    donde P es el número de parámetros, B es batch_size
    
    Complejidad espacial: O(P) para almacenar gradientes
    
    Args:
        model: Modelo MLP
        X: Datos de entrada
        y: Etiquetas
        epsilon: Perturbación pequeña
    
    Returns:
        Gradientes numéricos: dW1, db1, dW2, db2
    """
    # Guardar pesos originales
    W1_orig = model.W1.data.copy()
    b1_orig = model.b1.data.copy()
    W2_orig = model.W2.data.copy()
    b2_orig = model.b2.data.copy()
    
    # Función de pérdida (promedio sobre el batch)
    def loss_fn(W1, b1, W2, b2):
        model.W1 = Matrix(W1)
        model.b1 = Matrix(b1)
        model.W2 = Matrix(W2)
        model.b2 = Matrix(b2)
        _, _, a2 = model.forward(X)
        # La pérdida ya es el promedio, así que está bien
        return model.loss_fn(a2, y)
    
    # Gradiente numérico para W1 (usar siempre pesos originales)
    dW1_num = np.zeros_like(W1_orig)
    for i in range(W1_orig.shape[0]):
        for j in range(W1_orig.shape[1]):
            W1_plus = W1_orig.copy()
            W1_plus[i, j] += epsilon
            loss_plus = loss_fn(W1_plus, b1_orig, W2_orig, b2_orig)
            
            W1_minus = W1_orig.copy()
            W1_minus[i, j] -= epsilon
            loss_minus = loss_fn(W1_minus, b1_orig, W2_orig, b2_orig)
            
            dW1_num[i, j] = (loss_plus - loss_minus) / (2 * epsilon)
    
    # Gradiente numérico para b1
    db1_num = np.zeros_like(b1_orig)
    for j in range(b1_orig.shape[1]):
        b1_plus = b1_orig.copy()
        b1_plus[0, j] += epsilon
        loss_plus = loss_fn(W1_orig, b1_plus, W2_orig, b2_orig)
        
        b1_minus = b1_orig.copy()
        b1_minus[0, j] -= epsilon
        loss_minus = loss_fn(W1_orig, b1_minus, W2_orig, b2_orig)
        
        db1_num[0, j] = (loss_plus - loss_minus) / (2 * epsilon)
    
    # Gradiente numérico para W2
    dW2_num = np.zeros_like(W2_orig)
    for i in range(W2_orig.shape[0]):
        for j in range(W2_orig.shape[1]):
            W2_plus = W2_orig.copy()
            W2_plus[i, j] += epsilon
            loss_plus = loss_fn(W1_orig, b1_orig, W2_plus, b2_orig)
            
            W2_minus = W2_orig.copy()
            W2_minus[i, j] -= epsilon
            loss_minus = loss_fn(W1_orig, b1_orig, W2_minus, b2_orig)
            
            dW2_num[i, j] = (loss_plus - loss_minus) / (2 * epsilon)
    
    # Gradiente numérico para b2
    db2_num = np.zeros_like(b2_orig)
    for j in range(b2_orig.shape[1]):
        b2_plus = b2_orig.copy()
        b2_plus[0, j] += epsilon
        loss_plus = loss_fn(W1_orig, b1_orig, W2_orig, b2_plus)
        
        b2_minus = b2_orig.copy()
        b2_minus[0, j] -= epsilon
        loss_minus = loss_fn(W1_orig, b1_orig, W2_orig, b2_minus)
        
        db2_num[0, j] = (loss_plus - loss_minus) / (2 * epsilon)
    
    # Restaurar pesos originales (ya guardados al inicio)
    model.W1 = Matrix(W1_orig)
    model.b1 = Matrix(b1_orig)
    model.W2 = Matrix(W2_orig)
    model.b2 = Matrix(b2_orig)
    
    return Matrix(dW1_num), Matrix(db1_num), Matrix(dW2_num), Matrix(db2_num)


def gradient_check(
    model: MLP,
    X: Matrix,
    y: Matrix,
    tolerance: float = 1e-5
) -> bool:
    """
    Verifica que los gradientes analíticos coincidan con los numéricos
    
    Returns:
        True si los gradientes son correctos dentro de la tolerancia
    """
    # Gradientes analíticos
    z1, a1, a2 = model.forward(X)
    dW1_analytical, db1_analytical, dW2_analytical, db2_analytical = model.backward(X, y, z1, a1, a2)
    
    # Gradientes numéricos
    dW1_numerical, db1_numerical, dW2_numerical, db2_numerical = numerical_gradient(model, X, y)
    
    # Comparar usando múltiples métricas
    def compute_errors(analytical, numerical):
        diff = np.abs(analytical.data - numerical.data)
        # Error relativo estándar
        rel_error = diff / (np.abs(analytical.data) + np.abs(numerical.data) + 1e-10)
        max_rel = np.max(rel_error)
        mean_rel = np.mean(rel_error)
        
        # Error absoluto normalizado (más robusto para valores pequeños)
        abs_error = diff / (np.abs(analytical.data) + 1e-10)
        max_abs_norm = np.max(abs_error)
        mean_abs_norm = np.mean(abs_error)
        
        # Error absoluto máximo
        max_abs = np.max(diff)
        
        return {
            'max_rel': max_rel,
            'mean_rel': mean_rel,
            'max_abs_norm': max_abs_norm,
            'mean_abs_norm': mean_abs_norm,
            'max_abs': max_abs
        }
    
    errors_dw1 = compute_errors(dW1_analytical, dW1_numerical)
    errors_db1 = compute_errors(db1_analytical, db1_numerical)
    errors_dw2 = compute_errors(dW2_analytical, dW2_numerical)
    errors_db2 = compute_errors(db2_analytical, db2_numerical)
    
    # Usar error absoluto normalizado como métrica principal (más robusto)
    max_error = max(
        errors_dw1['max_abs_norm'],
        errors_db1['max_abs_norm'],
        errors_dw2['max_abs_norm'],
        errors_db2['max_abs_norm']
    )
    
    # Mostrar errores
    print(f"  dW1 - Max error abs norm: {errors_dw1['max_abs_norm']:.2e}, Max abs: {errors_dw1['max_abs']:.2e}")
    print(f"  db1 - Max error abs norm: {errors_db1['max_abs_norm']:.2e}, Max abs: {errors_db1['max_abs']:.2e}")
    print(f"  dW2 - Max error abs norm: {errors_dw2['max_abs_norm']:.2e}, Max abs: {errors_dw2['max_abs']:.2e}")
    print(f"  db2 - Max error abs norm: {errors_db2['max_abs_norm']:.2e}, Max abs: {errors_db2['max_abs']:.2e}")
    print(f"\nError maximo (absoluto normalizado): {max_error:.2e}")
    print(f"Tolerancia: {tolerance:.2e}")
    
    return max_error < tolerance


def load_mnist_reduced(n_samples: int = 1000, test_size: float = 0.2):
    """
    Carga una versión reducida de MNIST para pruebas rápidas
    
    Complejidad temporal: O(n_samples * 784) para cargar y procesar
    Complejidad espacial: O(n_samples * 784)
    """
    try:
        from sklearn.datasets import fetch_openml
        from sklearn.model_selection import train_test_split
        
        print("Cargando MNIST...")
        mnist = fetch_openml('mnist_784', version=1, as_frame=False, parser='auto')
        X, y = mnist.data, mnist.target.astype(int)
        
        # Reducir dataset
        indices = np.random.choice(len(X), n_samples, replace=False)
        X_reduced = X[indices] / 255.0  # Normalizar
        y_reduced = y[indices]
        
        # Dividir en train/test
        X_train, X_test, y_train, y_test = train_test_split(
            X_reduced, y_reduced, test_size=test_size, random_state=42
        )
        
        return (
            Matrix(X_train),
            Matrix(y_train),
            Matrix(X_test),
            Matrix(y_test)
        )
    except Exception as e:
        print(f"Error cargando MNIST: {e}")
        print("Generando datos sintéticos...")
        return generate_synthetic_data(n_samples, test_size)


def generate_synthetic_data(n_samples: int = 1000, test_size: float = 0.2, n_features: int = 784, n_classes: int = 10):
    """
    Genera datos sintéticos con estructura para que el modelo pueda aprender
    
    Complejidad temporal: O(n_samples * n_features)
    Complejidad espacial: O(n_samples * n_features)
    """
    np.random.seed(42)
    
    # Crear datos con estructura: cada clase tiene un centroide
    centroids = np.random.randn(n_classes, n_features) * 2.0
    
    X_list = []
    y_list = []
    
    for i in range(n_samples):
        # Asignar clase
        class_idx = i % n_classes
        # Generar punto alrededor del centroide de la clase
        X_point = centroids[class_idx] + np.random.randn(n_features) * 0.5
        X_list.append(X_point)
        y_list.append(class_idx)
    
    X = np.array(X_list)
    y = np.array(y_list)
    
    # Normalizar
    X = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-8)
    
    # Dividir
    split_idx = int(n_samples * (1 - test_size))
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]
    
    return (
        Matrix(X_train),
        Matrix(y_train),
        Matrix(X_test),
        Matrix(y_test)
    )

