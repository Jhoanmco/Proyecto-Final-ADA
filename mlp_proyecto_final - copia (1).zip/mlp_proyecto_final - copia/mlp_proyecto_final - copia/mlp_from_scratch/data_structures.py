"""
Estructuras de datos para optimización (Fase 3 - RA3)
Incluye: cola de lotes, hash de pérdidas, heap/BST para poda
"""
import numpy as np
from typing import List, Optional, Tuple, Dict
import heapq
from collections import deque


class BatchQueue:
    """
    Cola de lotes para manejar batches de entrenamiento
    
    Complejidad temporal:
    - Enqueue: O(1) amortizado
    - Dequeue: O(1)
    - Size: O(1)
    
    Complejidad espacial: O(B * n) donde B es capacidad y n es tamaño de muestra
    """
    
    def __init__(self, max_size: int = 1000):
        """
        Inicializa la cola de lotes
        
        Args:
            max_size: Tamaño máximo de la cola
        """
        self.queue = deque(maxlen=max_size)
        self.max_size = max_size
    
    def enqueue(self, batch: Tuple[np.ndarray, np.ndarray]):
        """
        Agrega un lote a la cola
        
        Complejidad temporal: O(1) amortizado
        Complejidad espacial: O(batch_size * feature_size)
        """
        self.queue.append(batch)
    
    def dequeue(self) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """
        Extrae un lote de la cola
        
        Complejidad temporal: O(1)
        Complejidad espacial: O(1)
        """
        if len(self.queue) == 0:
            return None
        return self.queue.popleft()
    
    def is_empty(self) -> bool:
        """O(1) tiempo"""
        return len(self.queue) == 0
    
    def size(self) -> int:
        """O(1) tiempo"""
        return len(self.queue)


class LossHash:
    """
    Hash table para almacenar y recuperar pérdidas por muestra
    
    Complejidad temporal:
    - Insert: O(1) promedio, O(n) peor caso (colisiones)
    - Get: O(1) promedio, O(n) peor caso
    - Update: O(1) promedio
    
    Complejidad espacial: O(n) donde n es el número de muestras
    """
    
    def __init__(self, initial_size: int = 1000):
        """
        Inicializa el hash de pérdidas
        
        Args:
            initial_size: Tamaño inicial de la tabla hash
        """
        self.size = initial_size
        self.table: List[List[Tuple[int, float]]] = [[] for _ in range(initial_size)]
        self.count = 0
        self.load_factor_threshold = 0.75
    
    def _hash(self, key: int) -> int:
        """Función hash simple. O(1) tiempo"""
        return key % self.size
    
    def _resize(self):
        """
        Redimensiona la tabla hash cuando el factor de carga es alto
        
        Complejidad temporal: O(n) donde n es el número de elementos
        Complejidad espacial: O(n)
        """
        old_table = self.table
        self.size *= 2
        self.table = [[] for _ in range(self.size)]
        self.count = 0
        
        for bucket in old_table:
            for key, value in bucket:
                self.insert(key, value)
    
    def insert(self, sample_idx: int, loss: float):
        """
        Inserta o actualiza una pérdida
        
        Complejidad temporal: O(1) promedio
        """
        if self.count / self.size > self.load_factor_threshold:
            self._resize()
        
        bucket_idx = self._hash(sample_idx)
        bucket = self.table[bucket_idx]
        
        # Buscar si ya existe
        for i, (key, _) in enumerate(bucket):
            if key == sample_idx:
                bucket[i] = (sample_idx, loss)
                return
        
        # Insertar nuevo
        bucket.append((sample_idx, loss))
        self.count += 1
    
    def get(self, sample_idx: int) -> Optional[float]:
        """
        Obtiene la pérdida de una muestra
        
        Complejidad temporal: O(1) promedio, O(k) peor caso donde k es tamaño del bucket
        """
        bucket_idx = self._hash(sample_idx)
        bucket = self.table[bucket_idx]
        
        for key, value in bucket:
            if key == sample_idx:
                return value
        
        return None
    
    def get_all(self) -> Dict[int, float]:
        """
        Obtiene todas las pérdidas
        
        Complejidad temporal: O(n)
        Complejidad espacial: O(n)
        """
        result = {}
        for bucket in self.table:
            for key, value in bucket:
                result[key] = value
        return result


class PruningHeap:
    """
    Heap para mantener los pesos más pequeños (para poda de neuronas)
    
    Complejidad temporal:
    - Insert: O(log n)
    - Extract min: O(log n)
    - Peek: O(1)
    
    Complejidad espacial: O(n) donde n es el número de pesos
    """
    
    def __init__(self):
        """Inicializa el heap de poda"""
        self.heap: List[Tuple[float, Tuple[int, int, int]]] = []
        # Tupla almacena: (valor_absoluto_peso, (capa, fila, columna))
    
    def insert(self, weight_value: float, layer: int, row: int, col: int):
        """
        Inserta un peso en el heap
        
        Complejidad temporal: O(log n)
        """
        heapq.heappush(self.heap, (abs(weight_value), (layer, row, col)))
    
    def extract_min(self) -> Optional[Tuple[float, Tuple[int, int, int]]]:
        """
        Extrae el peso más pequeño
        
        Complejidad temporal: O(log n)
        """
        if len(self.heap) == 0:
            return None
        return heapq.heappop(self.heap)
    
    def peek(self) -> Optional[Tuple[float, Tuple[int, int, int]]]:
        """
        Ve el peso más pequeño sin extraerlo
        
        Complejidad temporal: O(1)
        """
        if len(self.heap) == 0:
            return None
        return self.heap[0]
    
    def size(self) -> int:
        """O(1) tiempo"""
        return len(self.heap)
    
    def get_top_k(self, k: int) -> List[Tuple[float, Tuple[int, int, int]]]:
        """
        Obtiene los k pesos más pequeños
        
        Complejidad temporal: O(k log n)
        Complejidad espacial: O(k)
        """
        result = []
        temp_heap = self.heap.copy()
        
        for _ in range(min(k, len(temp_heap))):
            result.append(heapq.heappop(temp_heap))
        
        return result


class PruningBST:
    """
    Árbol de búsqueda binaria para poda (implementación simplificada)
    Permite búsqueda y eliminación eficiente de pesos
    
    Complejidad temporal:
    - Insert: O(log n) promedio, O(n) peor caso (árbol desbalanceado)
    - Search: O(log n) promedio, O(n) peor caso
    - Delete: O(log n) promedio, O(n) peor caso
    
    Complejidad espacial: O(n)
    """
    
    class Node:
        """Nodo del BST"""
        def __init__(self, weight_value: float, position: Tuple[int, int, int]):
            self.weight = abs(weight_value)
            self.position = position
            self.left: Optional['PruningBST.Node'] = None
            self.right: Optional['PruningBST.Node'] = None
    
    def __init__(self):
        """Inicializa el BST"""
        self.root: Optional[PruningBST.Node] = None
        self.size = 0
    
    def insert(self, weight_value: float, layer: int, row: int, col: int):
        """
        Inserta un peso en el BST
        
        Complejidad temporal: O(log n) promedio
        """
        node = PruningBST.Node(weight_value, (layer, row, col))
        self.root = self._insert_helper(self.root, node)
        self.size += 1
    
    def _insert_helper(self, root: Optional[Node], node: Node) -> Node:
        """Helper recursivo para inserción"""
        if root is None:
            return node
        
        if node.weight < root.weight:
            root.left = self._insert_helper(root.left, node)
        else:
            root.right = self._insert_helper(root.right, node)
        
        return root
    
    def find_min(self) -> Optional[Tuple[float, Tuple[int, int, int]]]:
        """
        Encuentra el peso mínimo
        
        Complejidad temporal: O(log n) promedio, O(n) peor caso
        """
        if self.root is None:
            return None
        
        node = self.root
        while node.left is not None:
            node = node.left
        
        return (node.weight, node.position)
    
    def delete_min(self) -> Optional[Tuple[float, Tuple[int, int, int]]]:
        """
        Elimina y retorna el peso mínimo
        
        Complejidad temporal: O(log n) promedio
        """
        if self.root is None:
            return None
        
        min_val = self.find_min()
        if min_val is None:
            return None
        
        self.root = self._delete_helper(self.root, min_val[0])
        self.size -= 1
        return min_val
    
    def _delete_helper(self, root: Optional[Node], key: float) -> Optional[Node]:
        """Helper recursivo para eliminación"""
        if root is None:
            return None
        
        if key < root.weight:
            root.left = self._delete_helper(root.left, key)
        elif key > root.weight:
            root.right = self._delete_helper(root.right, key)
        else:
            # Nodo a eliminar
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            
            # Nodo con dos hijos: encontrar sucesor
            min_node = root.right
            while min_node.left is not None:
                min_node = min_node.left
            
            root.weight = min_node.weight
            root.position = min_node.position
            root.right = self._delete_helper(root.right, min_node.weight)
        
        return root
    
    def get_size(self) -> int:
        """O(1) tiempo"""
        return self.size

