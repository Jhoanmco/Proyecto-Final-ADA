"""
MLP from Scratch - Proyecto Final Análisis y Diseño de Algoritmos 1
Implementación completa de perceptrón multicapa con análisis algorítmico
"""

__version__ = "1.0.0"

