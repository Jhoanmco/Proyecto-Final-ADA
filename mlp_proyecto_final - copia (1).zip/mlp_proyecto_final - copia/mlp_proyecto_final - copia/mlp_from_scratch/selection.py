"""
Módulos de selección y ordenamiento (Fase 2 - RA2)
Implementa Quickselect (mediana), top-k con heap vs sort, y hard mining
"""
import numpy as np
from typing import List, Tuple, Optional
import heapq


def quickselect(arr: np.ndarray, k: int, left: int = 0, right: Optional[int] = None) -> float:
    """
    Quickselect: encuentra el k-ésimo elemento más pequeño
    
    Complejidad temporal promedio: O(n) donde n = len(arr)
    Complejidad temporal peor caso: O(n²) si el pivote siempre es el extremo
    Complejidad espacial: O(1) iterativo, O(log n) recursivo en promedio
    
    Análisis de recurrencia:
    T(n) = T(n/2) + O(n) en promedio (divide y vencerás)
    Por el Método Maestro: a=1, b=2, f(n)=n
    Caso 2: T(n) = Θ(n log n) si f(n) = Θ(n^log_b(a))
    Pero en promedio, la partición divide en ~n/2, entonces T(n) = T(n/2) + O(n) = O(n)
    
    Args:
        arr: Array de números
        k: Índice del elemento a encontrar (0-indexed)
        left: Índice izquierdo
        right: Índice derecho
    
    Returns:
        El k-ésimo elemento más pequeño
    """
    if right is None:
        right = len(arr) - 1
    
    if left == right:
        return arr[left]
    
    # Partición (similar a Quicksort)
    pivot_idx = partition(arr, left, right)
    
    if k == pivot_idx:
        return arr[k]
    elif k < pivot_idx:
        return quickselect(arr, k, left, pivot_idx - 1)
    else:
        return quickselect(arr, k, pivot_idx + 1, right)


def partition(arr: np.ndarray, left: int, right: int) -> int:
    """
    Partición de Lomuto para Quickselect
    
    Complejidad temporal: O(n) donde n = right - left + 1
    Complejidad espacial: O(1)
    """
    pivot = arr[right]
    i = left
    
    for j in range(left, right):
        if arr[j] <= pivot:
            arr[i], arr[j] = arr[j], arr[i]
            i += 1
    
    arr[i], arr[right] = arr[right], arr[i]
    return i


def median_quickselect(arr: np.ndarray) -> float:
    """
    Encuentra la mediana usando Quickselect
    
    Complejidad temporal: O(n) promedio
    Complejidad espacial: O(1)
    """
    n = len(arr)
    arr_copy = arr.copy()  # No modificar el original
    
    if n % 2 == 1:
        return quickselect(arr_copy, n // 2)
    else:
        left_median = quickselect(arr_copy, n // 2 - 1)
        right_median = quickselect(arr_copy, n // 2)
        return (left_median + right_median) / 2.0


def top_k_heap(arr: np.ndarray, k: int) -> np.ndarray:
    """
    Encuentra los top-k elementos usando un min-heap
    
    Complejidad temporal: O(n log k) donde n = len(arr), k = número de elementos
    Complejidad espacial: O(k) para el heap
    
    Ventaja sobre sort: O(n log k) vs O(n log n) cuando k << n
    
    Args:
        arr: Array de números
        k: Número de elementos top a encontrar
    
    Returns:
        Array con los k elementos más grandes
    """
    if k >= len(arr):
        return np.sort(arr)[::-1]
    
    # Min-heap de tamaño k
    heap = []
    
    for num in arr:
        if len(heap) < k:
            heapq.heappush(heap, num)
        elif num > heap[0]:
            heapq.heapreplace(heap, num)
    
    # Extraer y ordenar (opcional, pero útil para comparación)
    result = sorted(heap, reverse=True)
    return np.array(result)


def top_k_sort(arr: np.ndarray, k: int) -> np.ndarray:
    """
    Encuentra los top-k elementos usando ordenamiento completo
    
    Complejidad temporal: O(n log n)
    Complejidad espacial: O(n) para la copia ordenada
    
    Args:
        arr: Array de números
        k: Número de elementos top a encontrar
    
    Returns:
        Array con los k elementos más grandes
    """
    sorted_arr = np.sort(arr)[::-1]
    return sorted_arr[:k]


def hard_mining(losses: np.ndarray, k: int, method: str = 'heap') -> np.ndarray:
    """
    Hard Negative Mining: encuentra las k muestras con mayor pérdida
    
    Complejidad temporal:
    - Con heap: O(n log k)
    - Con sort: O(n log n)
    
    Complejidad espacial:
    - Con heap: O(k)
    - Con sort: O(n)
    
    Args:
        losses: Array de pérdidas por muestra
        k: Número de muestras difíciles a seleccionar
        method: 'heap' o 'sort'
    
    Returns:
        Índices de las k muestras con mayor pérdida
    """
    n = len(losses)
    k = min(k, n)
    
    if method == 'heap':
        # Usar heap para eficiencia cuando k << n
        # O(n log k) tiempo, O(k) espacio
        heap = []
        for idx, loss in enumerate(losses):
            if len(heap) < k:
                heapq.heappush(heap, (loss, idx))
            elif loss > heap[0][0]:
                heapq.heapreplace(heap, (loss, idx))
        
        # Extraer índices
        indices = [idx for _, idx in heap]
        return np.array(indices)
    
    else:  # method == 'sort'
        # Ordenar completo: O(n log n) tiempo, O(n) espacio
        sorted_indices = np.argsort(losses)[::-1]
        return sorted_indices[:k]


def heapsort(arr: np.ndarray) -> np.ndarray:
    """
    Heapsort: ordenamiento usando heap
    
    Complejidad temporal: O(n log n) en todos los casos
    Complejidad espacial: O(1) si se hace in-place, O(n) si se crea nuevo array
    
    Análisis de recurrencia:
    T(n) = 2T(n/2) + O(log n) para heapify
    Por el Método Maestro: a=2, b=2, f(n)=log n
    Caso 1 no aplica, Caso 2: f(n) = Θ(n^log_b(a) * log^k n) con k=0
    Pero heapify es O(log n) y se llama n veces, entonces T(n) = O(n log n)
    """
    arr_copy = arr.copy()
    n = len(arr_copy)
    
    # Construir max-heap
    for i in range(n // 2 - 1, -1, -1):
        heapify(arr_copy, n, i)
    
    # Extraer elementos uno por uno
    for i in range(n - 1, 0, -1):
        arr_copy[0], arr_copy[i] = arr_copy[i], arr_copy[0]
        heapify(arr_copy, i, 0)
    
    return arr_copy


def heapify(arr: np.ndarray, n: int, i: int):
    """
    Mantiene la propiedad de max-heap
    
    Complejidad temporal: O(log n)
    Complejidad espacial: O(1)
    """
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    
    if left < n and arr[left] > arr[largest]:
        largest = left
    
    if right < n and arr[right] > arr[largest]:
        largest = right
    
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)


def quicksort(arr: np.ndarray) -> np.ndarray:
    """
    Quicksort: ordenamiento usando divide y vencerás
    
    Complejidad temporal promedio: O(n log n)
    Complejidad temporal peor caso: O(n²)
    Complejidad espacial: O(log n) para la pila de recursión
    
    Análisis de recurrencia:
    T(n) = T(k) + T(n-k-1) + O(n) donde k es el tamaño de una partición
    En promedio: k ≈ n/2, entonces T(n) = 2T(n/2) + O(n)
    Por el Método Maestro: a=2, b=2, f(n)=n
    Caso 2: T(n) = Θ(n log n)
    """
    arr_copy = arr.copy()
    _quicksort_helper(arr_copy, 0, len(arr_copy) - 1)
    return arr_copy


def _quicksort_helper(arr: np.ndarray, low: int, high: int):
    """Helper recursivo para Quicksort"""
    if low < high:
        pivot_idx = partition(arr, low, high)
        _quicksort_helper(arr, low, pivot_idx - 1)
        _quicksort_helper(arr, pivot_idx + 1, high)

