"""
Implementaciones baseline (Fase 4)
k-NN, Heapsort, Quicksort para comparación
"""
import numpy as np
from typing import List, Tuple, Optional
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.selection import heapsort, quicksort


class KNN:
    """
    k-Nearest Neighbors para clasificación
    
    Complejidad temporal:
    - Entrenamiento: O(1) - solo almacena datos
    - Predicción: O(n * d) donde n es número de muestras de entrenamiento, d es dimensión
    
    Complejidad espacial: O(n * d) para almacenar datos de entrenamiento
    """
    
    def __init__(self, k: int = 3):
        """
        Inicializa k-NN
        
        Args:
            k: Número de vecinos
        """
        self.k = k
        self.X_train: Optional[np.ndarray] = None
        self.y_train: Optional[np.ndarray] = None
    
    def fit(self, X: Matrix, y: Matrix):
        """
        Entrenamiento (solo almacena datos)
        
        Complejidad temporal: O(1)
        Complejidad espacial: O(n * d)
        """
        self.X_train = X.data.copy()
        self.y_train = y.data.copy()
    
    def predict(self, X: Matrix) -> np.ndarray:
        """
        Predicción usando k-NN
        
        Complejidad temporal: O(m * n * d) donde m es número de muestras de prueba
        Complejidad espacial: O(m * n) para distancias
        """
        if self.X_train is None or self.y_train is None:
            raise ValueError("Modelo no entrenado. Llama a fit() primero.")
        
        predictions = []
        
        for x_test in X.data:
            # Calcular distancias euclidianas
            # O(n * d) para cada muestra de prueba
            distances = np.sqrt(np.sum((self.X_train - x_test) ** 2, axis=1))
            
            # Encontrar k vecinos más cercanos
            # O(n log k) usando heap, O(n log n) usando sort completo
            k_indices = np.argpartition(distances, self.k)[:self.k]
            k_labels = self.y_train[k_indices]
            
            # Votación mayoritaria
            # O(k)
            unique, counts = np.unique(k_labels, return_counts=True)
            prediction = unique[np.argmax(counts)]
            predictions.append(prediction)
        
        return np.array(predictions)
    
    def evaluate(self, X: Matrix, y: Matrix) -> float:
        """
        Evalúa la precisión
        
        Complejidad temporal: O(m * n * d)
        """
        predictions = self.predict(X)
        accuracy = np.mean(predictions == y.data)
        return float(accuracy)


def compare_sorting_algorithms(arr: np.ndarray) -> dict:
    """
    Compara Heapsort vs Quicksort vs NumPy sort
    
    Complejidad temporal:
    - Heapsort: O(n log n)
    - Quicksort: O(n log n) promedio, O(n²) peor caso
    - NumPy sort: O(n log n) (Timsort)
    
    Returns:
        Diccionario con tiempos y resultados
    """
    import time
    
    results = {}
    
    # Heapsort
    arr_copy1 = arr.copy()
    start = time.time()
    sorted_heap = heapsort(arr_copy1)
    time_heap = time.time() - start
    results['heapsort'] = {'time': time_heap, 'sorted': sorted_heap}
    
    # Quicksort
    arr_copy2 = arr.copy()
    start = time.time()
    sorted_quick = quicksort(arr_copy2)
    time_quick = time.time() - start
    results['quicksort'] = {'time': time_quick, 'sorted': sorted_quick}
    
    # NumPy sort (baseline)
    arr_copy3 = arr.copy()
    start = time.time()
    sorted_numpy = np.sort(arr_copy3)
    time_numpy = time.time() - start
    results['numpy_sort'] = {'time': time_numpy, 'sorted': sorted_numpy}
    
    # Verificar que todos producen el mismo resultado
    assert np.allclose(sorted_heap, sorted_quick)
    assert np.allclose(sorted_heap, sorted_numpy)
    
    return results

