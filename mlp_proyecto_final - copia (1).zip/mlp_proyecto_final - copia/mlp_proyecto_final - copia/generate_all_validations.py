"""
Script para generar todas las validaciones y gráficas requeridas
Incluye: gradientes, memoria, poda, y precisión
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

print("=" * 80)
print("GENERACION DE TODAS LAS VALIDACIONES Y GRAFICAS")
print("=" * 80)
print()

# Crear directorio de resultados
os.makedirs('experiments/results', exist_ok=True)

# 1. Validación de gradientes
print("\n" + "=" * 80)
print("1. VALIDACION DE GRADIENTES")
print("=" * 80)
from experiments.experiment_gradient_validation import experiment_gradient_validation
experiment_gradient_validation()

# 2. Análisis de memoria
print("\n" + "=" * 80)
print("2. ANALISIS DE MEMORIA")
print("=" * 80)
from experiments.experiment_memory_detailed import experiment_memory_detailed
experiment_memory_detailed()

# 3. Impacto de poda
print("\n" + "=" * 80)
print("3. IMPACTO DE PODA")
print("=" * 80)
from experiments.experiment_pruning_impact import experiment_pruning_tradeoff
experiment_pruning_tradeoff()

# 4. Verificación de precisión >85%
print("\n" + "=" * 80)
print("4. VERIFICACION DE PRECISION >85%")
print("=" * 80)
from test_accuracy import test_with_mnist
test_with_mnist()

print("\n" + "=" * 80)
print("TODAS LAS VALIDACIONES COMPLETADAS")
print("=" * 80)
print("\nGráficas generadas en experiments/results/:")
print("  - gradient_validation.png: Validación de gradientes")
print("  - memory_detailed.png: Análisis detallado de memoria")
print("  - pruning_tradeoff.png: Trade-off de poda")
print("  - Todas las gráficas de experimentos RA1, RA2, RA3, Fase 4")
print("=" * 80)

