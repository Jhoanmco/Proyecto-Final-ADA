"""
Ejemplo de uso del MLP desde cero
"""
import numpy as np
from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data, gradient_check


def main():
    print("=" * 60)
    print("EJEMPLO: Entrenamiento de MLP desde cero")
    print("=" * 60)
    
    # Generar datos sintéticos
    print("\n1. Generando datos sintéticos...")
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=1000,
        n_features=100,
        n_classes=10,
        test_size=0.2
    )
    print(f"   Datos de entrenamiento: {X_train.data.shape}")
    print(f"   Datos de prueba: {X_test.data.shape}")
    
    # Crear modelo
    print("\n2. Creando modelo MLP...")
    mlp = MLP(
        input_size=100,
        hidden_size=50,
        output_size=10,
        activation='sigmoid',
        learning_rate=0.01,
        seed=42
    )
    print(f"   Arquitectura: 100 -> 50 -> 10")
    
    # Verificación de gradientes (opcional, puede ser lento)
    print("\n3. Verificando gradientes (opcional)...")
    try:
        X_small = Matrix(X_train.data[:10])
        y_small = Matrix(y_train.data[:10])
        is_correct = gradient_check(mlp, X_small, y_small, tolerance=1e-3)
        if is_correct:
            print("   ✓ Gradientes verificados correctamente")
        else:
            print("   ⚠ Advertencia en verificación de gradientes")
    except Exception as e:
        print(f"   (Saltando verificación: {e})")
    
    # Entrenar
    print("\n4. Entrenando modelo...")
    history = mlp.train(
        X_train, y_train,
        epochs=50,
        batch_size=32,
        X_val=X_test,
        y_val=y_test,
        verbose=True
    )
    
    # Evaluar
    print("\n5. Evaluando modelo...")
    accuracy = mlp.evaluate(X_test, y_test)
    print(f"   Precisión en test: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Mostrar historial
    print("\n6. Historial de entrenamiento:")
    print(f"   Pérdida inicial: {history[0]['loss']:.4f}")
    print(f"   Pérdida final: {history[-1]['loss']:.4f}")
    if 'val_accuracy' in history[-1]:
        print(f"   Precisión validación final: {history[-1]['val_accuracy']:.4f}")
    
    print("\n" + "=" * 60)
    print("Ejemplo completado")
    print("=" * 60)


if __name__ == "__main__":
    main()


