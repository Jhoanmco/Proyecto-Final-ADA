"""
Pruebas para algoritmos de selección y ordenamiento
"""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.selection import (
    quickselect, median_quickselect, top_k_heap, top_k_sort,
    hard_mining, heapsort, quicksort
)


def test_quickselect():
    """Prueba Quickselect"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5])
    k = 5
    
    result = quickselect(arr.copy(), k)
    sorted_arr = np.sort(arr)
    
    assert result == sorted_arr[k]
    print("[OK] Quickselect correcto")


def test_median_quickselect():
    """Prueba mediana con Quickselect"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6])
    median = median_quickselect(arr)
    expected = np.median(arr)
    
    assert abs(median - expected) < 1e-10
    print("[OK] Mediana con Quickselect correcta")


def test_top_k_heap():
    """Prueba top-k con heap"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5])
    k = 3
    
    result = top_k_heap(arr, k)
    expected = np.sort(arr)[-k:][::-1]
    
    assert np.allclose(result, expected)
    print("[OK] Top-k con heap correcto")


def test_top_k_sort():
    """Prueba top-k con sort"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5])
    k = 3
    
    result = top_k_sort(arr, k)
    expected = np.sort(arr)[-k:][::-1]
    
    assert np.allclose(result, expected)
    print("[OK] Top-k con sort correcto")


def test_hard_mining():
    """Prueba hard negative mining"""
    losses = np.array([0.1, 0.9, 0.3, 0.8, 0.2, 0.95, 0.4])
    k = 3
    
    indices_heap = hard_mining(losses, k, method='heap')
    indices_sort = hard_mining(losses, k, method='sort')
    
    # Verificar que ambos métodos dan los mismos índices
    assert len(indices_heap) == k
    assert len(indices_sort) == k
    
    # Los índices deberían corresponder a las mayores pérdidas
    top_losses_heap = losses[indices_heap]
    top_losses_sort = losses[indices_sort]
    
    assert np.allclose(np.sort(top_losses_heap)[::-1], np.sort(top_losses_sort)[::-1])
    print("[OK] Hard mining correcto")


def test_heapsort():
    """Prueba Heapsort"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5])
    sorted_arr = heapsort(arr)
    expected = np.sort(arr)
    
    assert np.allclose(sorted_arr, expected)
    print("[OK] Heapsort correcto")


def test_quicksort():
    """Prueba Quicksort"""
    arr = np.array([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5])
    sorted_arr = quicksort(arr)
    expected = np.sort(arr)
    
    assert np.allclose(sorted_arr, expected)
    print("[OK] Quicksort correcto")


if __name__ == "__main__":
    print("Ejecutando pruebas de selección y ordenamiento...\n")
    
    test_quickselect()
    test_median_quickselect()
    test_top_k_heap()
    test_top_k_sort()
    test_hard_mining()
    test_heapsort()
    test_quicksort()
    
    print("\n[OK] Todas las pruebas completadas")

