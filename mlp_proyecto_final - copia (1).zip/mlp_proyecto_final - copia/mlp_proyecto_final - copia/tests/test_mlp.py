"""
Pruebas unitarias para el MLP
"""
import numpy as np
import sys
import os

# Agregar el directorio raíz al path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import gradient_check, generate_synthetic_data


def test_mlp_initialization():
    """Prueba la inicialización del MLP"""
    mlp = MLP(input_size=10, hidden_size=5, output_size=3, seed=42)
    
    assert mlp.W1.shape == (10, 5)
    assert mlp.b1.shape == (1, 5)
    assert mlp.W2.shape == (5, 3)
    assert mlp.b2.shape == (1, 3)
    print("[OK] Inicializacion del MLP correcta")


def test_forward_propagation():
    """Prueba la propagación hacia adelante"""
    mlp = MLP(input_size=4, hidden_size=3, output_size=2, seed=42)
    X = Matrix(np.random.randn(5, 4))
    
    z1, a1, a2 = mlp.forward(X)
    
    assert z1.shape == (5, 3)
    assert a1.shape == (5, 3)
    assert a2.shape == (5, 2)
    assert np.allclose(np.sum(a2.data, axis=1), 1.0, atol=1e-6)  # Softmax suma a 1
    print("[OK] Forward propagation correcta")


def test_backward_propagation():
    """Prueba la propagación hacia atrás"""
    mlp = MLP(input_size=4, hidden_size=3, output_size=2, seed=42)
    X = Matrix(np.random.randn(5, 4))
    y = Matrix(np.random.randint(0, 2, 5))
    
    z1, a1, a2 = mlp.forward(X)
    dW1, db1, dW2, db2 = mlp.backward(X, y, z1, a1, a2)
    
    assert dW1.shape == mlp.W1.shape
    assert db1.shape == mlp.b1.shape
    assert dW2.shape == mlp.W2.shape
    assert db2.shape == mlp.b2.shape
    print("[OK] Backward propagation correcta")


def test_gradient_checking():
    """Prueba la verificación de gradientes"""
    mlp = MLP(input_size=5, hidden_size=3, output_size=2, seed=42)
    X = Matrix(np.random.randn(10, 5))
    y = Matrix(np.random.randint(0, 2, 10))
    
    # Usar un dataset pequeño para verificación rápida
    is_correct = gradient_check(mlp, X, y, tolerance=1e-3)
    
    if is_correct:
        print("[OK] Verificacion de gradientes correcta")
    else:
        print("[WARN] Advertencia: gradientes pueden tener pequenas diferencias numericas")


def test_training():
    """Prueba el entrenamiento básico"""
    mlp = MLP(input_size=10, hidden_size=5, output_size=3, learning_rate=0.01, seed=42)
    X_train, y_train, X_test, y_test = generate_synthetic_data(n_samples=100, n_features=10, n_classes=3)
    
    history = mlp.train(X_train, y_train, epochs=10, batch_size=10, verbose=False)
    
    assert len(history) == 10
    assert 'loss' in history[0]
    assert history[-1]['loss'] < history[0]['loss']  # Pérdida debería disminuir
    
    accuracy = mlp.evaluate(X_test, y_test)
    assert 0 <= accuracy <= 1
    print(f"[OK] Entrenamiento correcto. Precision final: {accuracy:.4f}")


def test_accuracy_threshold():
    """Prueba que el modelo puede alcanzar >85% en datos reducidos"""
    mlp = MLP(input_size=784, hidden_size=128, output_size=10, learning_rate=0.01, seed=42)
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=500, n_features=784, n_classes=10
    )
    
    # Entrenar más épocas
    mlp.train(X_train, y_train, epochs=50, batch_size=32, verbose=False)
    
    accuracy = mlp.evaluate(X_test, y_test)
    print(f"[OK] Precision en test: {accuracy:.4f}")
    
    # Nota: En datos sintéticos aleatorios, la precisión puede ser baja
    # En MNIST real debería ser >85%


if __name__ == "__main__":
    print("Ejecutando pruebas unitarias...\n")
    
    test_mlp_initialization()
    test_forward_propagation()
    test_backward_propagation()
    test_gradient_checking()
    test_training()
    test_accuracy_threshold()
    
    print("\n[OK] Todas las pruebas completadas")

