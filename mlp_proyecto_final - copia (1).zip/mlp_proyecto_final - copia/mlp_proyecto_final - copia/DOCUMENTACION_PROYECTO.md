# 📚 Documentación: Red Neuronal MLP Desde Cero

## 📋 Índice
1. [Visión General](#visión-general)
2. [Estructura del Proyecto](#estructura-del-proyecto)
3. [Componentes Principales](#componentes-principales)
4. [Proceso de Entrenamiento y Épocas](#proceso-de-entrenamiento-y-épocas)
5. [Cómo Ejecutar](#cómo-ejecutar)
6. [Análisis de Complejidad](#análisis-de-complejidad)

---

## 🎯 Visión General

Este proyecto implementa un **Perceptrón Multicapa (MLP)** completamente desde cero usando:
- **NumPy** para operaciones matriciales
- **Python puro** sin librerías de deep learning
- **Backpropagation** manual
- **Stochastic Gradient Descent (SGD)**

Es un proyecto educativo diseñado para entender cómo funcionan las redes neuronales a nivel fundamental.

---

## 📁 Estructura del Proyecto

```
mlp_proyecto_final/
├── mlp_from_scratch/          # Núcleo de la red neuronal
│   ├── mlp.py                # Red neuronal principal (MLP)
│   ├── matrix.py             # Operaciones matriciales
│   ├── activations.py        # Funciones de activación
│   ├── losses.py             # Funciones de pérdida
│   └── utils.py              # Utilidades (verificación de gradientes)
├── train_mlp.py              # Script para entrenar la red
├── example_usage.py          # Ejemplo de uso
└── run_tests.py              # Tests del proyecto
```

---

## 🔧 Componentes Principales

### 1️⃣ `mlp.py` - Red Neuronal MLP

El archivo central que contiene la clase `MLP` con toda la lógica de entrenamiento.

#### **Inicialización (`__init__`)**
```python
mlp = MLP(
    input_size=50,           # Características de entrada
    hidden_size=30,          # Neuronas en capa oculta
    output_size=5,           # Clases de salida
    activation='sigmoid',    # Función activación: sigmoid, relu, tanh
    loss='cross_entropy',    # Pérdida: mse, cross_entropy
    learning_rate=0.01,      # Tasa de aprendizaje
    seed=42                  # Reproducibilidad
)
```

**Inicialización de Pesos:**
- **Xavier/Glorot** para sigmoid/tanh
- **He initialization** para ReLU
- Asegura convergencia más rápida

#### **Forward Pass (Propagación Adelante)**
```python
def forward(self, X):
    z1 = X * W1 + b1           # Capa oculta pre-activación
    a1 = activation(z1)        # Capa oculta post-activación
    z2 = a1 * W2 + b2          # Capa salida pre-activación
    a2 = softmax(z2)           # Softmax para clasificación
    return z1, a1, a2
```

**Complejidad:** O(B × (n×h + h×c)) por lote

#### **Backward Pass (Retropropagación)**
```python
def backward(self, X, y, z1, a1, a2):
    # Gradiente de la pérdida
    dz2 = loss_derivative(a2, y)
    
    # Gradientes capa salida
    dW2 = a1^T · dz2 / m
    db2 = sum(dz2) / m
    
    # Propagación hacia atrás
    da1 = dz2 · W2^T
    dz1 = da1 * activation_derivative(z1)
    
    # Gradientes capa entrada
    dW1 = X^T · dz1 / m
    db1 = sum(dz1) / m
    
    return dW1, db1, dW2, db2
```

**Complejidad:** O(B × (n×h + h×c)) por lote

#### **Actualización de Pesos (SGD)**
```python
def update_weights(self, dW1, db1, dW2, db2):
    W1 = W1 - learning_rate * dW1
    b1 = b1 - learning_rate * db1
    W2 = W2 - learning_rate * dW2
    b2 = b2 - learning_rate * db2
```

---

### 2️⃣ `matrix.py` - Operaciones Matriciales

Implementa la clase `Matrix` que envuelve NumPy con análisis de complejidad.

#### **Operaciones Principales**

| Operación | Complejidad | Ejemplo |
|-----------|------------|---------|
| Suma/Resta | O(n×m) | `M1 + M2` |
| Multiplicación (elemento) | O(n×m) | `M1 * M2` |
| Multiplicación Matricial | O(n×m×p) | `M1.dot(M2)` |
| Transpuesta | O(n×m) | `M.T()` |
| Suma en eje | O(n×m) | `M.sum(axis=0)` |

#### **Ejemplo de Uso**
```python
from mlp_from_scratch.matrix import Matrix
import numpy as np

# Crear matrices
A = Matrix(np.random.randn(100, 50))
B = Matrix(np.random.randn(50, 10))

# Operaciones
C = A.dot(B)           # Multiplicación matricial
D = A + B.T()          # Suma y transpuesta
```

---

### 3️⃣ `activations.py` - Funciones de Activación

Define funciones de activación y sus derivadas.

#### **Funciones Disponibles**

| Función | Fórmula | Derivada | Uso |
|---------|---------|----------|-----|
| **Sigmoid** | σ(x) = 1/(1+e^-x) | σ'(x) = σ(x)×(1-σ(x)) | Capas ocultas |
| **ReLU** | max(0, x) | 1 si x>0, 0 sino | Capas ocultas (rápido) |
| **Tanh** | tanh(x) | 1 - tanh²(x) | Capas ocultas |
| **Softmax** | e^x_i / Σe^x | Jacobiano | Clasificación multiclase |

#### **Ejemplo**
```python
from mlp_from_scratch.activations import ACTIVATIONS

# Obtener función y derivada
activation_fn, activation_derivative = ACTIVATIONS['relu']

# Usar
z = Matrix(np.array([[1, -2, 3]]))
a = activation_fn(z)  # ReLU: [[1, 0, 3]]
grad = activation_derivative(z)  # Derivada
```

**Complejidad:** O(n) para todas

---

### 4️⃣ `losses.py` - Funciones de Pérdida

Define funciones de pérdida y sus derivadas.

#### **Funciones Disponibles**

| Pérdida | Fórmula | Uso |
|---------|---------|-----|
| **MSE** | (1/n)×Σ(y_pred - y_true)² | Regresión |
| **Cross-Entropy** | -(1/n)×Σ(y_true × log(y_pred)) | Clasificación |

#### **Ejemplo**
```python
from mlp_from_scratch.losses import LOSSES

# Obtener función y derivada
loss_fn, loss_derivative = LOSSES['cross_entropy']

# Usar
y_pred = Matrix(np.array([[0.7, 0.2, 0.1]]))
y_true = Matrix(np.array([[1, 0, 0]]))

loss_value = loss_fn(y_pred, y_true)
gradient = loss_derivative(y_pred, y_true)
```

**Complejidad:** O(n × c) donde c es número de clases

---

### 5️⃣ `utils.py` - Utilidades

Proporciona funciones para verificación y análisis.

#### **Verificación de Gradientes (Gradient Checking)**
```python
def numerical_gradient(model, X, y, epsilon=1e-7):
    """
    Verifica que los gradientes analíticos sean correctos
    comparándolos con gradientes numéricos
    
    Complejidad: O(P × B × (n×h + h×c))
    donde P es número de parámetros
    """
    # Calcula gradientes perturbando cada parámetro
    # Úselo para DEBUG, es muy lento para datos grandes
```

#### **Generación de Datos Sintéticos**
```python
def generate_synthetic_data(n_samples, n_features, n_classes, test_size=0.2):
    """
    Crea datos sintéticos para pruebas
    Retorna: X_train, y_train, X_test, y_test
    """
```

---

## 🚀 Proceso de Entrenamiento y Épocas

El método `train()` es el corazón del proyecto. Aquí está el flujo completo:

### **Pseudocódigo del Entrenamiento**

```python
def train(X, y, epochs=30, batch_size=32, X_val=None, y_val=None):
    for epoch in range(epochs):
        # 1. BARAJAR DATOS
        indices = permutation(N)
        X_shuffled = X[indices]
        y_shuffled = y[indices]
        
        epoch_loss = 0
        
        # 2. ITERAR POR LOTES
        for batch in range(num_batches):
            # Obtener lote
            X_batch = X_shuffled[start:end]
            y_batch = y_shuffled[start:end]
            
            # 3. FORWARD PASS
            z1, a1, a2 = forward(X_batch)
            
            # 4. CALCULAR PÉRDIDA
            loss = loss_fn(a2, y_batch)
            epoch_loss += loss
            
            # 5. BACKWARD PASS
            dW1, db1, dW2, db2 = backward(X_batch, y_batch, z1, a1, a2)
            
            # 6. ACTUALIZAR PESOS
            update_weights(dW1, db1, dW2, db2)
        
        # 7. CALCULAR MÉTRICAS
        avg_loss = epoch_loss / num_batches
        
        # 8. VALIDACIÓN (opcional)
        if X_val is not None:
            val_accuracy = evaluate(X_val, y_val)
        
        # 9. MOSTRAR PROGRESO
        if (epoch + 1) % 10 == 0:
            print(f"Época {epoch+1}/{epochs}, Pérdida: {avg_loss:.4f}")
```

### **Visualización de una Época**

```
┌─ ÉPOCA 1 ──────────────────────────────────┐
│                                              │
│  📊 PASO 1: Barajar datos (N muestras)     │
│    ✓ Orden aleatorio para evitar bias      │
│                                              │
│  🔄 PASO 2: Procesar lotes                 │
│    ├─ Lote 1 (32 muestras)                 │
│    │   ├─ Forward: 50→30→5                 │
│    │   ├─ Pérdida: 2.3                     │
│    │   ├─ Backward: Calcular gradientes    │
│    │   └─ SGD: Actualizar W1, W2, b1, b2  │
│    │                                        │
│    ├─ Lote 2 (32 muestras)                 │
│    │   └─ [Repetir proceso]                │
│    │                                        │
│    └─ Lote N (últimas muestras)            │
│        └─ [Repetir proceso]                │
│                                              │
│  📈 PASO 3: Calcular métricas              │
│    ├─ Pérdida promedio: 1.8                │
│    └─ Precisión validación: 0.75           │
│                                              │
└────────────────────────────────────────────┘
```

### **Flujo de Datos por Lote**

```
X_batch (32×50)
    ↓
┌───────────────────────────┐
│   FORWARD PASS            │
│   z1 = X × W1 + b1        │  O(32×50×30)
│   a1 = sigmoid(z1)        │
│   z2 = a1 × W2 + b2       │  O(32×30×5)
│   a2 = softmax(z2)        │
└───────────────────────────┘
    ↓ (32×5)
┌───────────────────────────┐
│   CALCULAR PÉRDIDA        │
│   L = -Σ(y×log(a2))      │  O(32×5)
└───────────────────────────┘
    ↓
┌───────────────────────────┐
│   BACKWARD PASS           │
│   dz2 = a2 - y            │  O(32×5)
│   dW2 = a1^T·dz2          │  O(30×5)
│   da1 = dz2·W2^T          │  O(32×30)
│   dz1 = da1 ⊙ σ'(z1)     │  O(32×30)
│   dW1 = X^T·dz1           │  O(50×30)
└───────────────────────────┘
    ↓
┌───────────────────────────┐
│   ACTUALIZAR PESOS        │
│   W1 = W1 - α×dW1         │  O(50×30)
│   W2 = W2 - α×dW2         │  O(30×5)
│   b1 = b1 - α×db1         │  O(30)
│   b2 = b2 - α×db2         │  O(5)
└───────────────────────────┘
    ↓
Siguiente Lote
```

---

## 🎮 Cómo Ejecutar

### **Opción 1: Script de Entrenamiento Simple**

```bash
python train_mlp.py
```

Este script:
- Genera datos sintéticos automáticamente
- Entrena una red neuronal con arquitectura 50→30→5
- Ejecuta 30 épocas con batch_size=32
- Muestra la precisión final

**Salida esperada:**
```
======================================================================
ENTRENAMIENTO DE RED NEURONAL MLP DESDE CERO
======================================================================

[1/5] Configurando parámetros...
  • Muestras: 1000
  • Arquitectura: 50 → 30 → 5
  • Épocas: 30

[2/5] Generando datos sintéticos...
  • Datos entrenamiento: (800, 50)
  • Datos prueba: (200, 50)

[3/5] Creando modelo MLP...
  ✓ Modelo creado exitosamente

[4/5] Entrenando modelo...
----------------------------------------------------------------------
Época 10/30, Pérdida: 1.2345, Precisión validación: 0.6500
Época 20/30, Pérdida: 0.8234, Precisión validación: 0.7800
Época 30/30, Pérdida: 0.5123, Precisión validación: 0.8500
----------------------------------------------------------------------

[5/5] Evaluando modelo...
  • Precisión entrenamiento: 0.9200 (92.00%)
  • Precisión prueba: 0.8500 (85.00%)

======================================================================
RESUMEN DEL ENTRENAMIENTO
======================================================================
Pérdida inicial: 2.314156
Pérdida final: 0.512345
Reducción de pérdida: 77.87%

Precisión final en validación: 0.8500
======================================================================
```

### **Opción 2: Ejemplo de Uso Personalizado**

```bash
python example_usage.py
```

Este script permite mayor control sobre los parámetros.

### **Opción 3: Código Personalizado**

```python
from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data
import numpy as np

# Generar datos
X_train, y_train, X_test, y_test = generate_synthetic_data(
    n_samples=1000,
    n_features=100,
    n_classes=10,
    test_size=0.2
)

# Crear modelo
mlp = MLP(
    input_size=100,
    hidden_size=64,
    output_size=10,
    activation='relu',
    learning_rate=0.01,
    seed=42
)

# Entrenar
history = mlp.train(
    X_train, y_train,
    epochs=50,
    batch_size=32,
    X_val=X_test,
    y_val=y_test,
    verbose=True
)

# Evaluar
accuracy = mlp.evaluate(X_test, y_test)
print(f"Precisión final: {accuracy:.4f}")

# Hacer predicciones
predictions = mlp.predict(X_test)
```

---

## 📊 Análisis de Complejidad

### **Complejidad Total por Época**

```
O(E × N × (n×h + h×c))

Donde:
  E = número de épocas
  N = número total de muestras
  n = tamaño de entrada
  h = tamaño capa oculta
  c = número de clases
```

### **Desglose por Operación (por lote)**

| Operación | Complejidad | Espacio |
|-----------|------------|---------|
| Forward | O(B×(n×h + h×c)) | O(B×(n+h+c)) |
| Backward | O(B×(n×h + h×c)) | O(n×h + h×c) |
| Update | O(n×h + h×c) | O(1) |
| **Total/lote** | **O(B×(n×h + h×c))** | **O(B×(n+h+c))** |

### **Ejemplo Numérico**

Para una red **100→64→10** con **1000 muestras** y **batch_size=32**:

```
Forward (por lote):
  X·W1: 32×100 × 100×64 = 204,800 ops ≈ 0.2M
  a1·W2: 32×64 × 64×10 = 20,480 ops ≈ 0.02M
  Total forward: ≈ 0.22M ops

Backward (por lote):
  Similar al forward: ≈ 0.22M ops

Por época (31 lotes):
  0.22M × 31 × 2 ≈ 13.6M operaciones

30 épocas:
  13.6M × 30 ≈ 408M operaciones
```

---

## 🔍 Verificación de Gradientes

Para asegurar que el backpropagation es correcto:

```python
from mlp_from_scratch.utils import gradient_check

# Crear modelo pequeño
mlp = MLP(input_size=10, hidden_size=5, output_size=2, seed=42)

# Generar datos pequeños
X_small = Matrix(np.random.randn(5, 10))
y_small = Matrix(np.array([[1, 0], [0, 1], [1, 0], [0, 1], [1, 0]]))

# Verificar gradientes
is_correct = gradient_check(mlp, X_small, y_small, tolerance=1e-3)
print("Gradientes correctos:", is_correct)
```

**Nota:** Esta verificación es lenta (O(P×B×(n×h+h×c))) y es solo para debugging.

---

## 📚 Referencias

- **Forward Propagation:** Calcula la salida de la red
- **Backpropagation:** Calcula gradientes de la pérdida
- **SGD:** Stochastic Gradient Descent - optimizador básico
- **Batch Training:** Procesar múltiples muestras juntas
- **Epoch:** Una pasada completa sobre todos los datos

---

## 🎓 Conclusión

Este proyecto demuestra cómo funcionan las redes neuronales desde cero:

1. **Inicialización inteligente** de pesos
2. **Forward pass** eficiente con matrices
3. **Backpropagation** correcta
4. **SGD** con mini-batches
5. **Validación** y monitoreo del entrenamiento

Todos estos conceptos son la base de frameworks modernos como TensorFlow y PyTorch.

