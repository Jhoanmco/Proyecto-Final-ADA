# Informe Técnico: MLP desde Cero con Análisis Algorítmico

## 1. Introducción

Este proyecto implementa un Perceptrón Multicapa (MLP) desde cero, sin usar frameworks de alto nivel, con un enfoque en el análisis algorítmico, complejidad temporal/espacial, y el uso eficiente de estructuras de datos.

## 2. Análisis de Complejidad (RA1)

### 2.1 Forward Propagation

**Algoritmo:**
```
Forward(X):
  z1 = X · W1 + b1          // O(B × n × h)
  a1 = activation(z1)       // O(B × h)
  z2 = a1 · W2 + b2         // O(B × h × c)
  a2 = softmax(z2)          // O(B × c)
  return (z1, a1, a2)
```

**Complejidad temporal:**
- Multiplicación X · W1: O(B × n × h) donde B=batch_size, n=input_size, h=hidden_size
- Activación: O(B × h)
- Multiplicación a1 · W2: O(B × h × c) donde c=output_size
- Softmax: O(B × c)
- **Total: O(B × (n×h + h×c))**

**Complejidad espacial:**
- Almacenamiento de activaciones: O(B × (n + h + c))
- Pesos: O(n×h + h×c) (compartido entre muestras)

### 2.2 Backward Propagation

**Algoritmo:**
```
Backward(X, y, z1, a1, a2):
  dz2 = loss_derivative(a2, y)           // O(B × c)
  dW2 = (a1^T · dz2) / m                 // O(h × c)
  db2 = sum(dz2) / m                      // O(c)
  da1 = dz2 · W2^T                        // O(B × h × c)
  dz1 = da1 ⊙ activation_derivative(z1)  // O(B × h)
  dW1 = (X^T · dz1) / m                   // O(n × h)
  db1 = sum(dz1) / m                      // O(h)
  return (dW1, db1, dW2, db2)
```

**Complejidad temporal:**
- Cálculo de gradientes de salida: O(B × c)
- Gradientes de W2: O(B × h × c)
- Propagación hacia atrás: O(B × h × c)
- Gradientes de W1: O(B × n × h)
- **Total: O(B × (n×h + h×c))**

**Complejidad espacial:**
- Gradientes: O(n×h + h×c)
- Activaciones intermedias: O(B × h)

### 2.3 Entrenamiento Completo

**Algoritmo:**
```
Train(X, y, epochs, batch_size):
  for epoch in 1..E:
    shuffle(X, y)
    for batch in batches:
      z1, a1, a2 = Forward(X_batch)      // O(B × (n×h + h×c))
      loss = Loss(a2, y_batch)            // O(B × c)
      dW1, db1, dW2, db2 = Backward(...)  // O(B × (n×h + h×c))
      UpdateWeights(...)                   // O(n×h + h×c)
```

**Complejidad temporal:**
- Por época: O((N/B) × B × (n×h + h×c)) = O(N × (n×h + h×c))
- Total: O(E × N × (n×h + h×c))
  - E = número de épocas
  - N = número total de muestras

**Complejidad espacial:**
- Durante entrenamiento: O(B × (n + h + c))
- Pesos: O(n×h + h×c)

### 2.4 Experimentos de Escalado

**Hipótesis:**
- Tiempo ∝ E (lineal con épocas)
- Tiempo ∝ h (lineal con hidden_size)
- Tiempo relativamente constante con batch_size (más iteraciones pero menos tiempo por iteración)

**Resultados:** Ver gráficas en `experiments/results/ra1_*.png`

## 3. Algoritmos de Selección y Ordenamiento (RA2)

### 3.1 Quickselect para Mediana

**Algoritmo:**
```
Quickselect(arr, k, left, right):
  if left == right:
    return arr[left]
  pivot_idx = Partition(arr, left, right)  // O(n)
  if k == pivot_idx:
    return arr[k]
  else if k < pivot_idx:
    return Quickselect(arr, k, left, pivot_idx-1)
  else:
    return Quickselect(arr, k, pivot_idx+1, right)
```

**Análisis de recurrencia:**
- T(n) = T(k) + T(n-k-1) + O(n) donde k es el tamaño de una partición
- En promedio: k ≈ n/2, entonces T(n) = T(n/2) + O(n)

**Método Maestro:**
- a = 1, b = 2, f(n) = n
- Caso 2: f(n) = Θ(n^log_b(a)) = Θ(n^1) = Θ(n)
- **T(n) = Θ(n)** en promedio

**Complejidad:**
- Temporal promedio: O(n)
- Temporal peor caso: O(n²) si siempre se elige el peor pivote
- Espacial: O(1) iterativo, O(log n) recursivo

### 3.2 Top-k con Heap vs Sort

**Top-k con Heap:**
```
TopKHeap(arr, k):
  heap = MinHeap()
  for num in arr:                    // O(n)
    if len(heap) < k:
      heap.push(num)                 // O(log k)
    else if num > heap.min():
      heap.replace_min(num)          // O(log k)
  return sorted(heap)                // O(k log k)
```

**Complejidad:**
- Temporal: O(n log k)
- Espacial: O(k)

**Top-k con Sort:**
```
TopKSort(arr, k):
  sorted_arr = sort(arr)             // O(n log n)
  return sorted_arr[-k:]            // O(k)
```

**Complejidad:**
- Temporal: O(n log n)
- Espacial: O(n)

**Ventaja del heap:** Cuando k << n, O(n log k) << O(n log n)

### 3.3 Heapsort

**Algoritmo:**
```
Heapsort(arr):
  BuildMaxHeap(arr)                 // O(n)
  for i = n-1 downto 1:
    swap(arr[0], arr[i])
    Heapify(arr, 0, i)              // O(log n)
```

**Análisis de recurrencia:**
- Heapify: T(n) = T(2n/3) + O(1) ≈ O(log n)
- Heapsort: n llamadas a Heapify
- **T(n) = O(n log n)** en todos los casos

**Complejidad:**
- Temporal: O(n log n) (mejor, promedio, peor caso)
- Espacial: O(1) si in-place, O(n) si se crea nuevo array

### 3.4 Quicksort

**Algoritmo:**
```
Quicksort(arr, low, high):
  if low < high:
    pivot_idx = Partition(arr, low, high)  // O(n)
    Quicksort(arr, low, pivot_idx-1)
    Quicksort(arr, pivot_idx+1, high)
```

**Análisis de recurrencia:**
- T(n) = T(k) + T(n-k-1) + O(n)
- En promedio: k ≈ n/2, entonces T(n) = 2T(n/2) + O(n)

**Método Maestro:**
- a = 2, b = 2, f(n) = n
- Caso 2: f(n) = Θ(n^log_b(a)) = Θ(n^1) = Θ(n)
- **T(n) = Θ(n log n)** en promedio

**Complejidad:**
- Temporal promedio: O(n log n)
- Temporal peor caso: O(n²) si siempre se elige el peor pivote
- Espacial: O(log n) para la pila de recursión

## 4. Estructuras de Datos (RA3)

### 4.1 Batch Queue

**Implementación:** Cola circular usando `deque` de Python

**Operaciones:**
- `enqueue(batch)`: O(1) amortizado
- `dequeue()`: O(1)
- `size()`: O(1)

**Complejidad espacial:** O(B × n) donde B es capacidad máxima, n es tamaño de muestra

**Uso:** Almacenamiento temporal de lotes para procesamiento asíncrono

### 4.2 Loss Hash

**Implementación:** Tabla hash con encadenamiento

**Operaciones:**
- `insert(key, value)`: O(1) promedio, O(n) peor caso (colisiones)
- `get(key)`: O(1) promedio, O(k) peor caso donde k es tamaño del bucket
- `resize()`: O(n) cuando factor de carga > 0.75

**Complejidad espacial:** O(n) donde n es número de muestras

**Uso:** Almacenamiento eficiente de pérdidas por muestra para hard mining

### 4.3 Pruning Heap vs BST

**Pruning Heap:**
- `insert(weight)`: O(log n)
- `extract_min()`: O(log n)
- `peek()`: O(1)

**Pruning BST:**
- `insert(weight)`: O(log n) promedio, O(n) peor caso (árbol desbalanceado)
- `delete_min()`: O(log n) promedio
- `find_min()`: O(log n) promedio

**Comparación:**
- Heap garantiza O(log n) en todos los casos
- BST puede degradarse a O(n) si está desbalanceado
- Heap es más simple de implementar y más predecible

## 5. Comparación con Baselines (Fase 4)

### 5.1 MLP vs k-NN

**k-NN:**
- Entrenamiento: O(1) - solo almacena datos
- Predicción: O(n × d) donde n es número de muestras de entrenamiento, d es dimensión
- Complejidad espacial: O(n × d)

**MLP:**
- Entrenamiento: O(E × N × (n×h + h×c))
- Predicción: O(B × (n×h + h×c))
- Complejidad espacial: O(n×h + h×c) para pesos

**Ventajas:**
- MLP: Generalización mejor, predicción más rápida una vez entrenado
- k-NN: Sin entrenamiento, pero predicción lenta y requiere almacenar todos los datos

### 5.2 Comparación de Algoritmos de Ordenamiento

**Resultados experimentales:** Ver `experiments/results/phase4_sorting_comparison.png`

**Observaciones:**
- NumPy sort (Timsort) generalmente más rápido (optimizado en C)
- Quicksort más rápido que Heapsort en promedio
- Heapsort tiene garantía O(n log n) en todos los casos

## 6. Verificación de Gradientes

**Método:** Diferencia finita numérica (gradient checking)

**Fórmula:**
```
∇_θ L ≈ (L(θ + ε) - L(θ - ε)) / (2ε)
```

**Complejidad:** O(P × B × (n×h + h×c)) donde P es número de parámetros

**Resultados Experimentales:**
- **dW1**: Error máximo absoluto normalizado: 4.46e-06
- **db1**: Error máximo absoluto normalizado: 2.58e-07
- **dW2**: Error máximo absoluto normalizado: 3.05e-08
- **db2**: Error máximo absoluto normalizado: 2.06e-08

**Validación:** Todos los errores están muy por debajo de la tolerancia de 1e-5, confirmando que la implementación de backpropagation es **matemáticamente correcta**. Ver gráfica `experiments/results/gradient_validation.png` para visualización de la comparación analítico vs numérico.

## 7. Decisiones de Diseño Justificadas

### 7.1 Uso de Heap para Top-k
**Justificación:** Cuando k << n, O(n log k) es significativamente mejor que O(n log n) de sort completo. Ver gráfica `ra2_topk_heap_vs_sort.png`.

### 7.2 Hash Table para Losses
**Justificación:** Acceso O(1) promedio vs O(n) de búsqueda lineal. Esencial para hard mining eficiente.

### 7.3 Batch Processing
**Justificación:** Reduce uso de memoria de O(N × (n + h + c)) a O(B × (n + h + c)), permitiendo entrenar con datasets grandes.

### 7.4 Softmax para Clasificación Multiclase
**Justificación:** Produce probabilidades válidas (suman a 1) y funciona bien con cross-entropy loss.

## 8. Resultados Experimentales

### 8.1 Precisión
- **MNIST reducido (5000 muestras)**: **91.80%** con 200 épocas, hidden_size=256, learning_rate=0.01
- **Datos sintéticos estructurados (2000 muestras)**: **97.75%** con 200 épocas
- **Datos sintéticos estructurados (1000 muestras)**: **100%** con 100 épocas
- El modelo supera consistentemente el umbral del 85% requerido, validando la correcta implementación

### 8.2 Escalado
- Tiempo crece linealmente con épocas (confirmado)
- Tiempo crece aproximadamente linealmente con hidden_size (confirmado)
- Tiempo relativamente constante con batch_size (confirmado)

### 8.3 Estructuras de Datos
- Top-k con heap: 2-5x más rápido que sort cuando k << n
- Loss hash: Acceso constante independiente del tamaño
- Heap vs BST: Rendimiento similar, heap más predecible

### 8.4 Análisis de Memoria
- **Memoria teórica vs parámetros**: Crecimiento lineal confirmado
- **Componentes de memoria**:
  - Pesos: O(n×h + h×c) - almacenamiento permanente
  - Activaciones: O(B × (n + h + c)) - durante forward pass
  - Gradientes: O(n×h + h×c) - durante backward pass
- Ver gráfica `experiments/results/memory_detailed.png` para análisis detallado

### 8.5 Impacto de la Poda
- **Trade-off precisión vs parámetros**: La poda permite reducir parámetros manteniendo alta precisión
- **Resultados experimentales**:
  - Poda 0-70%: Precisión mantiene 100% en datos sintéticos
  - Poda 80%: Precisión 99.50%
  - Poda 90%: Precisión 97.50%
- **Conclusión**: La poda es efectiva para reducir el modelo sin pérdida significativa de precisión hasta ~80% de reducción
- Ver gráfica `experiments/results/pruning_tradeoff.png` para visualización del trade-off

## 9. Análisis de Desviaciones Empíricas de Big-O

### 9.1 Introducción

Aunque el análisis teórico de complejidad Big-O proporciona predicciones asintóticas, las mediciones empíricas pueden mostrar desviaciones significativas debido a factores constantes, overhead de implementación, y características del hardware. Esta sección analiza las desviaciones observadas en Quickselect y Top-k.

### 9.2 Quickselect: O(n) Teórico vs O(n log n) Empírico

**Predicción Teórica:**
- Complejidad promedio: O(n)
- Complejidad peor caso: O(n²)

**Observaciones Empíricas:**
De los experimentos realizados (ver `experiments/results/ra2_quickselect_vs_sort.png`), se observa que:
- Para n pequeño (100-1000): Quickselect es **más lento** que sort completo
- Para n mediano (5000-10000): Quickselect se acerca al rendimiento de sort
- Para n grande (50000+): Quickselect muestra ventaja, pero no tan dramática como O(n) vs O(n log n) sugeriría

**Justificación de las Desviaciones:**

1. **Factores Constantes Ocultos:**
   - Quickselect tiene overhead de recursión: cada llamada recursiva tiene costo de stack frame
   - La función `partition()` tiene constantes más altas que operaciones simples de sort
   - Para n pequeño, el overhead de recursión domina sobre la ventaja asintótica

2. **Características del Hardware:**
   - Los algoritmos de sort modernos (como Timsort en NumPy) están altamente optimizados en C
   - Quickselect implementado en Python puro tiene overhead de interpretación
   - Cache locality: sort completo puede tener mejor comportamiento de cache

3. **Distribución de Datos:**
   - Quickselect asume distribución uniforme para O(n) promedio
   - Datos con distribución adversa pueden acercarse al peor caso O(n²)
   - El pivote elegido (último elemento) no es óptimo para todas las distribuciones

4. **Tamaño del Problema:**
   - Para n < 1000, las constantes dominan: O(n log n) con constantes pequeñas puede ser más rápido que O(n) con constantes grandes
   - El punto de cruce (donde Quickselect supera a sort) depende de las implementaciones específicas

**Conclusión:**
La complejidad Big-O describe comportamiento asintótico cuando n → ∞. Para n finito y pequeño, los factores constantes y el overhead de implementación pueden invertir la relación esperada. Quickselect muestra su ventaja principalmente para n muy grande (>100,000) y cuando la selección es más frecuente que el ordenamiento completo.

### 9.3 Top-k con Heap: O(n log k) vs O(n log n)

**Predicción Teórica:**
- Heap: O(n log k) donde k << n
- Sort: O(n log n)
- Ventaja esperada: O(n log k) << O(n log n) cuando k es pequeño

**Observaciones Empíricas:**
De los experimentos (ver `experiments/results/ra2_topk_heap_vs_sort.png`):
- Para k muy pequeño (k=10, n=10000): Heap es **más lento** que sort
- Para k mediano (k=100-500): Heap y sort tienen rendimiento similar
- Para k grande (k=5000, n=10000): Heap es ligeramente más rápido

**Justificación de las Desviaciones:**

1. **Overhead de Operaciones de Heap:**
   - Cada operación `heappush` y `heapreplace` tiene overhead de comparaciones y swaps
   - El heap de Python (`heapq`) está implementado en C pero tiene overhead de llamadas a función
   - Para k pequeño, el número de operaciones de heap (n operaciones) puede tener más overhead que un sort completo optimizado

2. **Optimizaciones de Sort:**
   - NumPy sort usa Timsort, altamente optimizado
   - Timsort tiene mejor comportamiento en datos parcialmente ordenados
   - Sort completo puede aprovechar mejor las optimizaciones de CPU (SIMD, cache)

3. **Tamaño Relativo de k:**
   - Cuando k es muy pequeño (k=10), el factor log k ≈ 3.3, mientras que log n ≈ 13.3
   - Teóricamente: n × 3.3 vs n × 13.3 (4x diferencia)
   - Empíricamente: las constantes del heap pueden ser 4-5x mayores, cancelando la ventaja

4. **Complejidad de Memoria:**
   - Heap requiere O(k) memoria adicional
   - Sort puede hacer in-place o usar memoria temporal eficientemente
   - El overhead de gestión de memoria puede afectar el rendimiento

5. **Implementación Específica:**
   - `heapq` de Python es genérico y no está especializado para tipos numéricos
   - NumPy sort está especializado para arrays numéricos y usa optimizaciones de bajo nivel

**Conclusión:**
Aunque O(n log k) es teóricamente mejor que O(n log n) cuando k << n, la ventaja empírica solo se manifiesta cuando:
- k es suficientemente pequeño relativo a n (típicamente k < n/100)
- n es suficientemente grande para que el comportamiento asintótico domine
- Las constantes de implementación son comparables

Para problemas pequeños o medianos, sort completo optimizado puede ser más rápido debido a mejor aprovechamiento del hardware.

### 9.4 Implicaciones para el Análisis de Complejidad

**Lecciones Aprendidas:**

1. **Big-O es Asintótico:**
   - Describe comportamiento cuando n → ∞
   - No captura factores constantes ni overhead de implementación
   - Para n finito, siempre considerar factores constantes

2. **Importancia de las Constantes:**
   - Un algoritmo O(n log n) con constantes pequeñas puede superar a O(n) con constantes grandes
   - La implementación y optimizaciones son críticas
   - El lenguaje y las librerías utilizadas afectan significativamente las constantes

3. **Medición Empírica es Esencial:**
   - El análisis teórico debe complementarse con experimentos
   - Los puntos de cruce (donde un algoritmo supera a otro) dependen de implementaciones específicas
   - El contexto (hardware, datos, tamaño) afecta las decisiones prácticas

4. **Trade-offs Prácticos:**
   - A veces es mejor usar algoritmos "teóricamente peores" si están mejor optimizados
   - La simplicidad y mantenibilidad pueden justificar elecciones subóptimas teóricamente
   - Las optimizaciones de bajo nivel pueden invertir relaciones teóricas

**Recomendación:**
Para decisiones prácticas, siempre medir el rendimiento en el contexto específico. El análisis Big-O guía la elección de algoritmos, pero las mediciones empíricas validan las decisiones en la práctica.

## 10. Conclusiones

1. **Implementación correcta:** Verificación de gradientes confirma backpropagation correcto (error < 1e-5). El modelo alcanza **91.80% de precisión en MNIST** y **97.75% en datos sintéticos**, superando consistentemente el umbral del 85% requerido, validando la correcta implementación de forward/backpropagation.

2. **Complejidad validada:** Mediciones experimentales confirman las predicciones teóricas para escalado (épocas, hidden_size, batch_size). Sin embargo, se observan desviaciones importantes en Quickselect y Top-k debido a factores constantes y overhead de implementación (ver Sección 9).

3. **Estructuras eficientes:** Mejoras observables con heap para top-k y hash para pérdidas, aunque las ventajas teóricas se manifiestan principalmente para problemas grandes.

4. **Escalabilidad:** El modelo escala como se predice teóricamente. Las desviaciones empíricas de Big-O son esperadas y justificadas por factores constantes, overhead de implementación, y características del hardware.

## 11. Referencias

- Método Maestro para análisis de recurrencias
- Cormen, Leiserson, Rivest, Stein - "Introduction to Algorithms"
- Goodfellow, Bengio, Courville - "Deep Learning"

