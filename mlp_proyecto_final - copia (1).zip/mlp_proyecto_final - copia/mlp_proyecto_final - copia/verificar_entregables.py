"""
Script para verificar que todos los entregables estén presentes
"""
import os
import sys

print("=" * 80)
print("VERIFICACION DE ENTREGABLES")
print("=" * 80)

# Verificar gráficas
results_dir = 'experiments/results'
required_graphs = [
    # RA1
    'ra1_batch_size.png',
    'ra1_hidden_size.png',
    'ra1_epochs.png',
    'ra1_memory.png',
    # RA2
    'ra2_quickselect_vs_sort.png',
    'ra2_topk_heap_vs_sort.png',
    'ra2_heapsort_vs_quicksort.png',
    'ra2_hard_mining.png',
    # RA3
    'ra3_batch_queue.png',
    'ra3_loss_hash.png',
    'ra3_pruning_heap_vs_bst.png',
    # Fase 4
    'phase4_mlp_vs_knn.png',
    'phase4_sorting_comparison.png',
    # Validaciones
    'gradient_validation.png',
    'memory_detailed.png',
    'pruning_tradeoff.png',
]

print("\n1. VERIFICACION DE GRAFICAS")
print("-" * 80)
if os.path.exists(results_dir):
    existing_files = os.listdir(results_dir)
    existing_graphs = [f for f in existing_files if f.endswith('.png')]
    
    missing = []
    for graph in required_graphs:
        if graph in existing_graphs:
            print(f"  [OK] {graph}")
        else:
            print(f"  [FALTA] {graph}")
            missing.append(graph)
    
    print(f"\n  Total requeridas: {len(required_graphs)}")
    print(f"  Presentes: {len(required_graphs) - len(missing)}")
    print(f"  Faltantes: {len(missing)}")
    
    if len(missing) == 0:
        print("\n  [OK] Todas las graficas estan presentes")
    else:
        print(f"\n  [WARN] Faltan {len(missing)} graficas")
else:
    print("  [ERROR] Directorio experiments/results/ no existe")

# Verificar documentación
print("\n2. VERIFICACION DE DOCUMENTACION")
print("-" * 80)
required_docs = [
    'README.md',
    'INFORME_TECNICO.md',
    'RESUMEN_PROYECTO.md',
    'ENTREGABLES.md',
    'VALIDACION_FINAL.md',
    'RESUMEN_FINAL.md',
]

for doc in required_docs:
    if os.path.exists(doc):
        size = os.path.getsize(doc)
        print(f"  [OK] {doc} ({size} bytes)")
    else:
        print(f"  [FALTA] {doc}")

# Verificar código fuente
print("\n3. VERIFICACION DE CODIGO FUENTE")
print("-" * 80)
required_code = [
    'mlp_from_scratch/mlp.py',
    'mlp_from_scratch/matrix.py',
    'mlp_from_scratch/activations.py',
    'mlp_from_scratch/losses.py',
    'mlp_from_scratch/selection.py',
    'mlp_from_scratch/data_structures.py',
    'mlp_from_scratch/baselines.py',
    'mlp_from_scratch/utils.py',
]

for code_file in required_code:
    if os.path.exists(code_file):
        print(f"  [OK] {code_file}")
    else:
        print(f"  [FALTA] {code_file}")

# Verificar scripts
print("\n4. VERIFICACION DE SCRIPTS")
print("-" * 80)
required_scripts = [
    'run_experiments.py',
    'run_tests.py',
    'test_accuracy.py',
    'test_gradient_verification.py',
    'generate_all_validations.py',
]

for script in required_scripts:
    if os.path.exists(script):
        print(f"  [OK] {script}")
    else:
        print(f"  [FALTA] {script}")

print("\n" + "=" * 80)
print("VERIFICACION COMPLETA")
print("=" * 80)

