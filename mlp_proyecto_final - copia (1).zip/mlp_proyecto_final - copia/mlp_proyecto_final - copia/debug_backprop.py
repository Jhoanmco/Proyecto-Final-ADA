"""
Script de depuración para encontrar el error en backpropagation
"""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix

# Crear modelo muy pequeño
mlp = MLP(input_size=3, hidden_size=2, output_size=2, seed=42)

# Datos muy simples
X = Matrix(np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]))
y = Matrix(np.array([0, 1]))

print("Forward pass:")
z1, a1, a2 = mlp.forward(X)
print(f"z1 shape: {z1.shape}, data:\n{z1.data}")
print(f"a1 shape: {a1.shape}, data:\n{a1.data}")
print(f"a2 shape: {a2.shape}, data:\n{a2.data}")
print(f"a2 sum (debe ser ~1.0 por fila): {np.sum(a2.data, axis=1)}")

print("\nLoss:")
loss = mlp.loss_fn(a2, y)
print(f"Loss: {loss}")

print("\nBackward pass:")
dz2 = mlp.loss_derivative(a2, y)
print(f"dz2 shape: {dz2.shape}")
print(f"dz2 data:\n{dz2.data}")
print(f"dz2 sum (debe ser ~0): {np.sum(dz2.data, axis=0)}")

dW1, db1, dW2, db2 = mlp.backward(X, y, z1, a1, a2)
print(f"\ndW2 shape: {dW2.shape}, data:\n{dW2.data}")
print(f"db2 shape: {db2.shape}, data:\n{db2.data}")
print(f"dW1 shape: {dW1.shape}, data:\n{dW1.data}")
print(f"db1 shape: {db1.shape}, data:\n{db1.data}")

