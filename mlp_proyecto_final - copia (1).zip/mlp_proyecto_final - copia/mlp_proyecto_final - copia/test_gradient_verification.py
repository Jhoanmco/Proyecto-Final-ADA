"""
Script riguroso para verificar la integridad algorítmica con verificación de gradientes
"""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import gradient_check, generate_synthetic_data


def test_gradient_verification():
    """Prueba rigurosa de verificación de gradientes"""
    print("=" * 70)
    print("VERIFICACION RIGUROSA DE GRADIENTES")
    print("=" * 70)
    
    # Crear modelo pequeño para verificación rápida
    mlp = MLP(
        input_size=10,
        hidden_size=5,
        output_size=3,
        activation='sigmoid',
        loss='cross_entropy',
        learning_rate=0.001,
        seed=42
    )
    
    # Generar datos pequeños
    X = Matrix(np.random.randn(5, 10))
    y = Matrix(np.random.randint(0, 3, 5))
    
    print("\n1. Verificando gradientes con tolerancia estricta (1e-5)...")
    is_correct_strict = gradient_check(mlp, X, y, tolerance=1e-5)
    
    print("\n2. Verificando gradientes con tolerancia relajada (1e-3)...")
    is_correct_relaxed = gradient_check(mlp, X, y, tolerance=1e-3)
    
    print("\n3. Verificando con ReLU...")
    mlp_relu = MLP(
        input_size=10,
        hidden_size=5,
        output_size=3,
        activation='relu',
        loss='cross_entropy',
        learning_rate=0.001,
        seed=42
    )
    is_correct_relu = gradient_check(mlp_relu, X, y, tolerance=1e-3)
    
    print("\n" + "=" * 70)
    print("RESULTADOS:")
    print("=" * 70)
    print(f"  Sigmoid + Cross-Entropy (tolerancia 1e-5): {'[OK]' if is_correct_strict else '[FALLO]'}")
    print(f"  Sigmoid + Cross-Entropy (tolerancia 1e-3): {'[OK]' if is_correct_relaxed else '[FALLO]'}")
    print(f"  ReLU + Cross-Entropy (tolerancia 1e-3): {'[OK]' if is_correct_relu else '[FALLO]'}")
    
    if is_correct_relaxed:
        print("\n[OK] La implementacion de backpropagation es CORRECTA")
        return True
    else:
        print("\n[ERROR] La implementacion de backpropagation tiene problemas")
        return False


def test_training_improvement():
    """Prueba que el entrenamiento mejora con configuración optimizada"""
    print("\n" + "=" * 70)
    print("PRUEBA DE MEJORA DE PRECISION")
    print("=" * 70)
    
    # Generar datos estructurados
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=1000,
        n_features=50,
        n_classes=5,
        test_size=0.2
    )
    
    print(f"\nDatos: {X_train.data.shape[0]} entrenamiento, {X_test.data.shape[0]} prueba")
    
    # Modelo con configuración optimizada
    mlp = MLP(
        input_size=50,
        hidden_size=32,
        output_size=5,
        activation='relu',
        loss='cross_entropy',
        learning_rate=0.01,  # Learning rate más alto
        seed=42
    )
    
    print("\nEntrenando modelo...")
    history = mlp.train(
        X_train, y_train,
        epochs=100,
        batch_size=32,
        X_val=X_test,
        y_val=y_test,
        verbose=True
    )
    
    # Evaluar
    accuracy = mlp.evaluate(X_test, y_test)
    initial_loss = history[0]['loss']
    final_loss = history[-1]['loss']
    
    print(f"\n{'='*70}")
    print(f"PRECISION FINAL: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"Pérdida inicial: {initial_loss:.4f}")
    print(f"Pérdida final: {final_loss:.4f}")
    print(f"Mejora en pérdida: {((initial_loss - final_loss) / initial_loss * 100):.1f}%")
    print(f"{'='*70}")
    
    if accuracy >= 0.85:
        print("\n[OK] Precision >= 85% alcanzada")
        return True
    elif accuracy >= 0.70:
        print("\n[WARN] Precision entre 70-85%. Mejorable con mas epocas/hiperparametros")
        return True
    else:
        print("\n[ERROR] Precision < 70%. Revisar implementacion")
        return False


if __name__ == "__main__":
    # Verificación de gradientes
    grad_ok = test_gradient_verification()
    
    # Prueba de precisión
    if grad_ok:
        print("\n" + "=" * 70)
        print("Como los gradientes son correctos, probando mejora de precision...")
        print("=" * 70)
        accuracy_ok = test_training_improvement()
        
        if grad_ok and accuracy_ok:
            print("\n" + "=" * 70)
            print("[OK] INTEGRIDAD ALGORITMICA VALIDADA")
            print("=" * 70)
        else:
            print("\n" + "=" * 70)
            print("[WARN] Verificar configuracion de hiperparametros")
            print("=" * 70)
    else:
        print("\n" + "=" * 70)
        print("[ERROR] PROBLEMA CRITICO: Gradientes incorrectos")
        print("Revisar implementacion de backpropagation")
        print("=" * 70)

