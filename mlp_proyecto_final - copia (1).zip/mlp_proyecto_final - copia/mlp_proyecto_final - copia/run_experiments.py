"""
Script principal para ejecutar todos los experimentos
"""
import sys
import os

# Agregar el directorio raíz al path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from experiments.experiment_ra1 import *
from experiments.experiment_ra2 import *
from experiments.experiment_ra3 import *
from experiments.experiment_phase4 import *


def main():
    """Ejecuta todos los experimentos"""
    print("=" * 80)
    print("PROYECTO FINAL: MLP DESDE CERO CON ANÁLISIS ALGORÍTMICO")
    print("=" * 80)
    print()
    
    # Crear directorio de resultados
    os.makedirs('experiments/results', exist_ok=True)
    
    # Fase 1 (RA1)
    print("\n" + "=" * 80)
    print("FASE 1 (RA1): Escalado con B, h, E")
    print("=" * 80)
    experiment_batch_size()
    experiment_hidden_size()
    experiment_epochs()
    try:
        experiment_memory()
    except:
        pass
    
    # Fase 2 (RA2)
    print("\n" + "=" * 80)
    print("FASE 2 (RA2): Algoritmos de Selección y Ordenamiento")
    print("=" * 80)
    from mlp_from_scratch.selection import hard_mining
    experiment_quickselect_vs_sort()
    experiment_top_k_heap_vs_sort()
    experiment_heapsort_vs_quicksort()
    experiment_hard_mining()
    
    # Fase 3 (RA3)
    print("\n" + "=" * 80)
    print("FASE 3 (RA3): Estructuras de Datos")
    print("=" * 80)
    experiment_batch_queue()
    experiment_loss_hash()
    experiment_pruning_heap_vs_bst()
    
    # Fase 4
    print("\n" + "=" * 80)
    print("FASE 4: Comparación con Baselines")
    print("=" * 80)
    experiment_mlp_vs_knn()
    experiment_sorting_comparison()
    
    print("\n" + "=" * 80)
    print("TODOS LOS EXPERIMENTOS COMPLETADOS")
    print("Resultados guardados en experiments/results/")
    print("=" * 80)


if __name__ == "__main__":
    main()

