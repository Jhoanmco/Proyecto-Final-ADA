"""
Experimentos Fase 3 (RA3): Estructuras de datos
Evaluación de impacto en tiempo y memoria
"""
import numpy as np
import matplotlib.pyplot as plt
import time
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.data_structures import BatchQueue, LossHash, PruningHeap, PruningBST
from mlp_from_scratch.matrix import Matrix


def experiment_batch_queue():
    """
    Evalúa el impacto de la cola de lotes
    """
    print("Experimento: Batch Queue")
    
    queue_sizes = [10, 50, 100, 500, 1000]
    enqueue_times = []
    dequeue_times = []
    
    batch_size = 32
    feature_size = 100
    
    for max_size in queue_sizes:
        queue = BatchQueue(max_size=max_size)
        
        # Crear lotes de prueba
        batches = [
            (np.random.randn(batch_size, feature_size), 
             np.random.randint(0, 10, batch_size))
            for _ in range(max_size)
        ]
        
        # Medir enqueue
        start = time.time()
        for batch in batches:
            queue.enqueue(batch)
        enqueue_time = (time.time() - start) / max_size
        enqueue_times.append(enqueue_time)
        
        # Medir dequeue
        start = time.time()
        while not queue.is_empty():
            queue.dequeue()
        dequeue_time = (time.time() - start) / max_size
        dequeue_times.append(dequeue_time)
        
        print(f"  Max size {max_size:4d}: Enqueue={enqueue_time:.6f}s, Dequeue={dequeue_time:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(queue_sizes, enqueue_times, 'o-', label='Enqueue (O(1) amortizado)')
    plt.plot(queue_sizes, dequeue_times, 's-', label='Dequeue (O(1))')
    plt.xlabel('Tamaño máximo de la cola')
    plt.ylabel('Tiempo promedio por operación (segundos)')
    plt.title('Rendimiento de Batch Queue')
    plt.legend()
    plt.grid(True)
    plt.savefig('experiments/results/ra3_batch_queue.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra3_batch_queue.png\n")


def experiment_loss_hash():
    """
    Evalúa el hash de pérdidas
    """
    print("Experimento: Loss Hash")
    
    n_samples = [100, 500, 1000, 5000, 10000, 50000]
    insert_times = []
    get_times = []
    
    for n in n_samples:
        loss_hash = LossHash(initial_size=1000)
        
        # Medir inserción
        start = time.time()
        for i in range(n):
            loss_hash.insert(i, np.random.rand())
        insert_time = (time.time() - start) / n
        insert_times.append(insert_time)
        
        # Medir obtención
        indices = np.random.randint(0, n, min(1000, n))
        start = time.time()
        for idx in indices:
            loss_hash.get(idx)
        get_time = (time.time() - start) / len(indices)
        get_times.append(get_time)
        
        print(f"  n={n:6d}: Insert={insert_time:.6f}s, Get={get_time:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(n_samples, insert_times, 'o-', label='Insert (O(1) promedio)')
    plt.plot(n_samples, get_times, 's-', label='Get (O(1) promedio)')
    plt.xlabel('Número de muestras')
    plt.ylabel('Tiempo promedio por operación (segundos)')
    plt.title('Rendimiento de Loss Hash')
    plt.legend()
    plt.grid(True)
    plt.xscale('log')
    plt.savefig('experiments/results/ra3_loss_hash.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra3_loss_hash.png\n")


def experiment_pruning_heap_vs_bst():
    """
    Compara heap vs BST para poda
    """
    print("Experimento: Pruning Heap vs BST")
    
    n_weights = [100, 500, 1000, 5000, 10000, 50000]
    times_heap_insert = []
    times_bst_insert = []
    times_heap_extract = []
    times_bst_extract = []
    
    for n in n_weights:
        weights = np.random.randn(n)
        
        # Heap
        heap = PruningHeap()
        start = time.time()
        for i, w in enumerate(weights):
            heap.insert(w, 0, i // 100, i % 100)
        time_heap_insert = (time.time() - start) / n
        times_heap_insert.append(time_heap_insert)
        
        start = time.time()
        for _ in range(min(100, n)):
            heap.extract_min()
        time_heap_extract = (time.time() - start) / min(100, n)
        times_heap_extract.append(time_heap_extract)
        
        # BST
        bst = PruningBST()
        start = time.time()
        for i, w in enumerate(weights):
            bst.insert(w, 0, i // 100, i % 100)
        time_bst_insert = (time.time() - start) / n
        times_bst_insert.append(time_bst_insert)
        
        start = time.time()
        for _ in range(min(100, n)):
            bst.delete_min()
        time_bst_extract = (time.time() - start) / min(100, n)
        times_bst_extract.append(time_bst_extract)
        
        print(f"  n={n:6d}: Heap insert={time_heap_insert:.6f}s, extract={time_heap_extract:.6f}s")
        print(f"           BST insert={time_bst_insert:.6f}s, extract={time_bst_extract:.6f}s")
    
    # Gráfica
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    ax1.plot(n_weights, times_heap_insert, 'o-', label='Heap (O(log n))')
    ax1.plot(n_weights, times_bst_insert, 's-', label='BST (O(log n) promedio)')
    ax1.set_xlabel('Número de pesos')
    ax1.set_ylabel('Tiempo promedio por inserción (segundos)')
    ax1.set_title('Inserción: Heap vs BST')
    ax1.legend()
    ax1.grid(True)
    ax1.set_xscale('log')
    
    ax2.plot(n_weights, times_heap_extract, 'o-', label='Heap (O(log n))')
    ax2.plot(n_weights, times_bst_extract, 's-', label='BST (O(log n) promedio)')
    ax2.set_xlabel('Número de pesos')
    ax2.set_ylabel('Tiempo promedio por extracción (segundos)')
    ax2.set_title('Extracción: Heap vs BST')
    ax2.legend()
    ax2.grid(True)
    ax2.set_xscale('log')
    
    plt.tight_layout()
    plt.savefig('experiments/results/ra3_pruning_heap_vs_bst.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra3_pruning_heap_vs_bst.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTOS FASE 3 (RA3)")
    print("=" * 60 + "\n")
    
    experiment_batch_queue()
    experiment_loss_hash()
    experiment_pruning_heap_vs_bst()
    
    print("=" * 60)
    print("Experimentos RA3 completados")
    print("=" * 60)

