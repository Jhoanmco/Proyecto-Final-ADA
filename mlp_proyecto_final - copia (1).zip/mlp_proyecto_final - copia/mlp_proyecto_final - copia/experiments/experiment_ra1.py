"""
Experimentos Fase 1 (RA1): Escalado con B, h, E
Análisis de complejidad temporal y espacial
"""
import numpy as np
import matplotlib.pyplot as plt
import time
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data


def experiment_batch_size():
    """
    Experimento: Tiempo de entrenamiento vs Batch Size (B)
    
    Hipótesis: Tiempo por época debería ser O(N/B * B * (n*h + h*c)) = O(N * (n*h + h*c))
    El tiempo total debería ser relativamente constante, pero el número de iteraciones cambia
    """
    print("Experimento: Tiempo vs Batch Size")
    
    input_size = 100
    hidden_size = 50
    output_size = 10
    epochs = 10
    n_samples = 1000
    
    batch_sizes = [8, 16, 32, 64, 128, 256]
    times = []
    
    X_train, y_train, _, _ = generate_synthetic_data(
        n_samples=n_samples, n_features=input_size, n_classes=output_size
    )
    
    for batch_size in batch_sizes:
        mlp = MLP(input_size, hidden_size, output_size, seed=42)
        
        start = time.time()
        mlp.train(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=False)
        elapsed = time.time() - start
        
        times.append(elapsed)
        print(f"  Batch size {batch_size:3d}: {elapsed:.4f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(batch_sizes, times, 'o-', label='Tiempo de entrenamiento')
    plt.xlabel('Batch Size (B)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Tiempo de Entrenamiento vs Batch Size\n(10 épocas, 1000 muestras)')
    plt.grid(True)
    plt.legend()
    plt.savefig('experiments/results/ra1_batch_size.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra1_batch_size.png\n")


def experiment_hidden_size():
    """
    Experimento: Tiempo de entrenamiento vs Hidden Size (h)
    
    Hipótesis: Tiempo debería ser O(E * N * (n*h + h*c)) = O(E * N * h * (n + c))
    Debería crecer linealmente con h
    """
    print("Experimento: Tiempo vs Hidden Size")
    
    input_size = 100
    output_size = 10
    epochs = 10
    batch_size = 32
    n_samples = 500
    
    hidden_sizes = [10, 20, 50, 100, 200, 500]
    times = []
    
    X_train, y_train, _, _ = generate_synthetic_data(
        n_samples=n_samples, n_features=input_size, n_classes=output_size
    )
    
    for hidden_size in hidden_sizes:
        mlp = MLP(input_size, hidden_size, output_size, seed=42)
        
        start = time.time()
        mlp.train(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=False)
        elapsed = time.time() - start
        
        times.append(elapsed)
        print(f"  Hidden size {hidden_size:3d}: {elapsed:.4f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(hidden_sizes, times, 'o-', label='Tiempo de entrenamiento')
    plt.xlabel('Hidden Size (h)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Tiempo de Entrenamiento vs Hidden Size\n(10 épocas, batch_size=32)')
    plt.grid(True)
    plt.legend()
    plt.savefig('experiments/results/ra1_hidden_size.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra1_hidden_size.png\n")


def experiment_epochs():
    """
    Experimento: Tiempo de entrenamiento vs Número de Épocas (E)
    
    Hipótesis: Tiempo debería ser O(E * N * (n*h + h*c))
    Debería crecer linealmente con E
    """
    print("Experimento: Tiempo vs Número de Épocas")
    
    input_size = 100
    hidden_size = 50
    output_size = 10
    batch_size = 32
    n_samples = 500
    
    epochs_list = [5, 10, 20, 50, 100]
    times = []
    
    X_train, y_train, _, _ = generate_synthetic_data(
        n_samples=n_samples, n_features=input_size, n_classes=output_size
    )
    
    for epochs in epochs_list:
        mlp = MLP(input_size, hidden_size, output_size, seed=42)
        
        start = time.time()
        mlp.train(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=False)
        elapsed = time.time() - start
        
        times.append(elapsed)
        print(f"  Épocas {epochs:3d}: {elapsed:.4f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(epochs_list, times, 'o-', label='Tiempo de entrenamiento')
    plt.xlabel('Número de Épocas (E)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Tiempo de Entrenamiento vs Número de Épocas\n(batch_size=32, hidden_size=50)')
    plt.grid(True)
    plt.legend()
    plt.savefig('experiments/results/ra1_epochs.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra1_epochs.png\n")


def experiment_memory():
    """
    Experimento: Memoria vs Parámetros
    """
    print("Experimento: Memoria vs Parámetros")
    
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    
    input_size = 100
    output_size = 10
    batch_size = 32
    n_samples = 500
    
    hidden_sizes = [10, 20, 50, 100, 200, 500]
    memory_usage = []
    param_counts = []
    
    X_train, y_train, _, _ = generate_synthetic_data(
        n_samples=n_samples, n_features=input_size, n_classes=output_size
    )
    
    for hidden_size in hidden_sizes:
        mlp = MLP(input_size, hidden_size, output_size, seed=42)
        
        # Contar parámetros
        n_params = (input_size * hidden_size + hidden_size + 
                   hidden_size * output_size + output_size)
        param_counts.append(n_params)
        
        # Medir memoria antes y después de entrenar
        mem_before = process.memory_info().rss / 1024 / 1024  # MB
        mlp.train(X_train, y_train, epochs=5, batch_size=batch_size, verbose=False)
        mem_after = process.memory_info().rss / 1024 / 1024  # MB
        
        memory_usage.append(mem_after - mem_before)
        print(f"  Hidden size {hidden_size:3d}: {n_params:6d} params, {mem_after - mem_before:.2f} MB")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(param_counts, memory_usage, 'o-', label='Uso de memoria')
    plt.xlabel('Número de Parámetros')
    plt.ylabel('Memoria (MB)')
    plt.title('Memoria vs Número de Parámetros')
    plt.grid(True)
    plt.legend()
    plt.savefig('experiments/results/ra1_memory.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra1_memory.png\n")


if __name__ == "__main__":
    # Crear directorio de resultados
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTOS FASE 1 (RA1)")
    print("=" * 60 + "\n")
    
    experiment_batch_size()
    experiment_hidden_size()
    experiment_epochs()
    
    try:
        experiment_memory()
    except ImportError:
        print("  (psutil no disponible, saltando experimento de memoria)\n")
    
    print("=" * 60)
    print("Experimentos RA1 completados")
    print("=" * 60)

