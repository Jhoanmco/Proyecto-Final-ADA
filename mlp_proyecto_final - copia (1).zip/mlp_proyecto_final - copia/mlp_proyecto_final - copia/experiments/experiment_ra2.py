"""
Experimentos Fase 2 (RA2): Comparación de algoritmos de selección
Análisis de recurrencias y Método Maestro
"""
import numpy as np
import matplotlib.pyplot as plt
import time
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.selection import (
    quickselect, median_quickselect, top_k_heap, top_k_sort,
    heapsort, quicksort, hard_mining
)


def experiment_quickselect_vs_sort():
    """
    Compara Quickselect vs ordenamiento completo para encontrar mediana
    """
    print("Experimento: Quickselect vs Sort para mediana")
    
    sizes = [100, 500, 1000, 5000, 10000, 50000]
    times_quickselect = []
    times_sort = []
    
    for n in sizes:
        arr = np.random.randn(n)
        
        # Quickselect
        start = time.time()
        median_qs = median_quickselect(arr.copy())
        time_qs = time.time() - start
        times_quickselect.append(time_qs)
        
        # Sort completo
        start = time.time()
        median_sort = np.median(arr.copy())
        time_sort = time.time() - start
        times_sort.append(time_sort)
        
        print(f"  n={n:6d}: Quickselect={time_qs:.6f}s, Sort={time_sort:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(sizes, times_quickselect, 'o-', label='Quickselect (O(n) promedio)')
    plt.plot(sizes, times_sort, 's-', label='Sort completo (O(n log n))')
    plt.xlabel('Tamaño del array (n)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Comparación: Quickselect vs Sort para Mediana')
    plt.legend()
    plt.grid(True)
    plt.xscale('log')
    plt.yscale('log')
    plt.savefig('experiments/results/ra2_quickselect_vs_sort.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra2_quickselect_vs_sort.png\n")


def experiment_top_k_heap_vs_sort():
    """
    Compara top-k con heap vs sort completo
    Hipótesis: heap debería ser mejor cuando k << n
    """
    print("Experimento: Top-k Heap vs Sort")
    
    n = 10000
    k_values = [10, 50, 100, 500, 1000, 5000]
    times_heap = []
    times_sort = []
    
    arr = np.random.randn(n)
    
    for k in k_values:
        # Heap
        start = time.time()
        result_heap = top_k_heap(arr.copy(), k)
        time_heap = time.time() - start
        times_heap.append(time_heap)
        
        # Sort
        start = time.time()
        result_sort = top_k_sort(arr.copy(), k)
        time_sort = time.time() - start
        times_sort.append(time_sort)
        
        # Verificar que dan el mismo resultado
        assert np.allclose(np.sort(result_heap)[::-1], np.sort(result_sort)[::-1])
        
        print(f"  k={k:5d}: Heap={time_heap:.6f}s, Sort={time_sort:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(k_values, times_heap, 'o-', label='Top-k con Heap (O(n log k))')
    plt.plot(k_values, times_sort, 's-', label='Top-k con Sort (O(n log n))')
    plt.xlabel('k (número de elementos top)')
    plt.ylabel('Tiempo (segundos)')
    plt.title(f'Comparación: Top-k Heap vs Sort (n={n})')
    plt.legend()
    plt.grid(True)
    plt.savefig('experiments/results/ra2_topk_heap_vs_sort.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra2_topk_heap_vs_sort.png\n")


def experiment_heapsort_vs_quicksort():
    """
    Compara Heapsort vs Quicksort
    """
    print("Experimento: Heapsort vs Quicksort")
    
    sizes = [100, 500, 1000, 5000, 10000, 50000]
    times_heap = []
    times_quick = []
    times_numpy = []
    
    for n in sizes:
        arr = np.random.randn(n)
        
        # Heapsort
        start = time.time()
        sorted_heap = heapsort(arr.copy())
        time_heap = time.time() - start
        times_heap.append(time_heap)
        
        # Quicksort
        start = time.time()
        sorted_quick = quicksort(arr.copy())
        time_quick = time.time() - start
        times_quick.append(time_quick)
        
        # NumPy sort (baseline)
        start = time.time()
        sorted_numpy = np.sort(arr.copy())
        time_numpy = time.time() - start
        times_numpy.append(time_numpy)
        
        # Verificar
        assert np.allclose(sorted_heap, sorted_quick)
        assert np.allclose(sorted_heap, sorted_numpy)
        
        print(f"  n={n:6d}: Heap={time_heap:.6f}s, Quick={time_quick:.6f}s, NumPy={time_numpy:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(sizes, times_heap, 'o-', label='Heapsort (O(n log n))')
    plt.plot(sizes, times_quick, 's-', label='Quicksort (O(n log n) promedio)')
    plt.plot(sizes, times_numpy, '^-', label='NumPy sort (Timsort)')
    plt.xlabel('Tamaño del array (n)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Comparación: Heapsort vs Quicksort vs NumPy Sort')
    plt.legend()
    plt.grid(True)
    plt.xscale('log')
    plt.yscale('log')
    plt.savefig('experiments/results/ra2_heapsort_vs_quicksort.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra2_heapsort_vs_quicksort.png\n")


def experiment_hard_mining():
    """
    Compara hard mining con heap vs sort
    """
    print("Experimento: Hard Mining Heap vs Sort")
    
    n_samples = 10000
    k_values = [100, 500, 1000, 2000, 5000]
    times_heap = []
    times_sort = []
    
    losses = np.random.rand(n_samples)
    
    for k in k_values:
        # Heap
        start = time.time()
        indices_heap = hard_mining(losses.copy(), k, method='heap')
        time_heap = time.time() - start
        times_heap.append(time_heap)
        
        # Sort
        start = time.time()
        indices_sort = hard_mining(losses.copy(), k, method='sort')
        time_sort = time.time() - start
        times_sort.append(time_sort)
        
        # Verificar que dan los mismos índices (pueden estar en orden diferente)
        top_losses_heap = np.sort(losses[indices_heap])[::-1]
        top_losses_sort = np.sort(losses[indices_sort])[::-1]
        assert np.allclose(top_losses_heap, top_losses_sort)
        
        print(f"  k={k:5d}: Heap={time_heap:.6f}s, Sort={time_sort:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(k_values, times_heap, 'o-', label='Hard Mining con Heap')
    plt.plot(k_values, times_sort, 's-', label='Hard Mining con Sort')
    plt.xlabel('k (número de muestras difíciles)')
    plt.ylabel('Tiempo (segundos)')
    plt.title(f'Comparación: Hard Mining (n={n_samples})')
    plt.legend()
    plt.grid(True)
    plt.savefig('experiments/results/ra2_hard_mining.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/ra2_hard_mining.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTOS FASE 2 (RA2)")
    print("=" * 60 + "\n")
    
    experiment_quickselect_vs_sort()
    experiment_top_k_heap_vs_sort()
    experiment_heapsort_vs_quicksort()
    experiment_hard_mining()
    
    print("=" * 60)
    print("Experimentos RA2 completados")
    print("=" * 60)

