"""
Experimentos Fase 4: Comparación con baselines
k-NN vs MLP, comparación de algoritmos de ordenamiento
"""
import numpy as np
import matplotlib.pyplot as plt
import time
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.baselines import KNN, compare_sorting_algorithms
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data


def experiment_mlp_vs_knn():
    """
    Compara MLP vs k-NN en clasificación
    """
    print("Experimento: MLP vs k-NN")
    
    n_samples = 1000
    n_features = 100
    n_classes = 10
    test_size = 0.2
    
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=n_samples, n_features=n_features, n_classes=n_classes, test_size=test_size
    )
    
    # Entrenar MLP
    print("  Entrenando MLP...")
    mlp = MLP(input_size=n_features, hidden_size=50, output_size=n_classes, seed=42)
    start = time.time()
    mlp.train(X_train, y_train, epochs=50, batch_size=32, verbose=False)
    mlp_time = time.time() - start
    mlp_accuracy = mlp.evaluate(X_test, y_test)
    
    # Entrenar k-NN
    print("  Entrenando k-NN...")
    knn = KNN(k=5)
    start = time.time()
    knn.fit(X_train, y_train)
    knn_time = time.time() - start
    
    start = time.time()
    knn_accuracy = knn.evaluate(X_test, y_test)
    knn_pred_time = time.time() - start
    
    print(f"\n  Resultados:")
    print(f"    MLP - Precisión: {mlp_accuracy:.4f}, Tiempo entrenamiento: {mlp_time:.4f}s")
    print(f"    k-NN - Precisión: {knn_accuracy:.4f}, Tiempo entrenamiento: {knn_time:.4f}s, Tiempo predicción: {knn_pred_time:.4f}s")
    
    # Gráfica comparativa
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    models = ['MLP', 'k-NN']
    accuracies = [mlp_accuracy, knn_accuracy]
    times = [mlp_time, knn_time]
    
    ax1.bar(models, accuracies, color=['blue', 'green'])
    ax1.set_ylabel('Precisión')
    ax1.set_title('Comparación de Precisión: MLP vs k-NN')
    ax1.set_ylim([0, 1])
    ax1.grid(True, axis='y')
    
    ax2.bar(models, times, color=['blue', 'green'])
    ax2.set_ylabel('Tiempo de entrenamiento (segundos)')
    ax2.set_title('Comparación de Tiempo: MLP vs k-NN')
    ax2.grid(True, axis='y')
    
    plt.tight_layout()
    plt.savefig('experiments/results/phase4_mlp_vs_knn.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/phase4_mlp_vs_knn.png\n")


def experiment_sorting_comparison():
    """
    Compara diferentes algoritmos de ordenamiento
    """
    print("Experimento: Comparación de Algoritmos de Ordenamiento")
    
    sizes = [100, 500, 1000, 5000, 10000, 50000, 100000]
    times_heap = []
    times_quick = []
    times_numpy = []
    
    for n in sizes:
        arr = np.random.randn(n)
        
        results = compare_sorting_algorithms(arr)
        
        times_heap.append(results['heapsort']['time'])
        times_quick.append(results['quicksort']['time'])
        times_numpy.append(results['numpy_sort']['time'])
        
        print(f"  n={n:6d}: Heap={results['heapsort']['time']:.6f}s, "
              f"Quick={results['quicksort']['time']:.6f}s, "
              f"NumPy={results['numpy_sort']['time']:.6f}s")
    
    # Gráfica
    plt.figure(figsize=(10, 6))
    plt.plot(sizes, times_heap, 'o-', label='Heapsort')
    plt.plot(sizes, times_quick, 's-', label='Quicksort')
    plt.plot(sizes, times_numpy, '^-', label='NumPy sort (Timsort)')
    plt.xlabel('Tamaño del array (n)')
    plt.ylabel('Tiempo (segundos)')
    plt.title('Comparación Final: Algoritmos de Ordenamiento')
    plt.legend()
    plt.grid(True)
    plt.xscale('log')
    plt.yscale('log')
    plt.savefig('experiments/results/phase4_sorting_comparison.png', dpi=150)
    plt.close()
    
    print("  Gráfica guardada en experiments/results/phase4_sorting_comparison.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTOS FASE 4")
    print("=" * 60 + "\n")
    
    experiment_mlp_vs_knn()
    experiment_sorting_comparison()
    
    print("=" * 60)
    print("Experimentos Fase 4 completados")
    print("=" * 60)

