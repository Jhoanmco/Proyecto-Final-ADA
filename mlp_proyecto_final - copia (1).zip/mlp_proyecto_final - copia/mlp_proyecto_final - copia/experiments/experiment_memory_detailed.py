"""
Experimento detallado de memoria vs parámetros
Incluye análisis de memoria durante entrenamiento
"""
import numpy as np
import matplotlib.pyplot as plt
import sys
import os
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data


def experiment_memory_detailed():
    """
    Análisis detallado de memoria vs parámetros y batch size
    """
    print("Experimento: Análisis Detallado de Memoria")
    
    try:
        import psutil
        import os
        process = psutil.Process(os.getpid())
    except ImportError:
        print("  psutil no disponible, usando estimaciones teóricas")
        process = None
    
    # Variar hidden_size
    input_size = 100
    output_size = 10
    batch_size = 32
    n_samples = 500
    
    hidden_sizes = [10, 20, 50, 100, 200, 500]
    param_counts = []
    memory_usage = []
    theoretical_memory = []
    
    X_train, y_train, _, _ = generate_synthetic_data(
        n_samples=n_samples, n_features=input_size, n_classes=output_size
    )
    
    for hidden_size in hidden_sizes:
        # Calcular número de parámetros
        n_params = (input_size * hidden_size + hidden_size + 
                   hidden_size * output_size + output_size)
        param_counts.append(n_params)
        
        # Memoria teórica (en bytes, asumiendo float64)
        # Pesos: n_params * 8 bytes
        # Activaciones durante forward: batch_size * (input_size + hidden_size + output_size) * 8
        # Gradientes: n_params * 8
        weights_mem = n_params * 8
        activations_mem = batch_size * (input_size + hidden_size + output_size) * 8
        gradients_mem = n_params * 8
        total_theoretical = (weights_mem + activations_mem + gradients_mem) / (1024 * 1024)  # MB
        theoretical_memory.append(total_theoretical)
        
        if process is not None:
            # Medir memoria real
            mem_before = process.memory_info().rss / 1024 / 1024  # MB
            mlp = MLP(input_size, hidden_size, output_size, seed=42)
            mlp.train(X_train, y_train, epochs=5, batch_size=batch_size, verbose=False)
            mem_after = process.memory_info().rss / 1024 / 1024  # MB
            memory_usage.append(mem_after - mem_before)
        else:
            memory_usage.append(total_theoretical)
        
        print(f"  Hidden size {hidden_size:3d}: {n_params:6d} params, "
              f"Memoria teórica: {total_theoretical:.2f} MB")
    
    # Gráfica
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Gráfica 1: Memoria vs Parámetros
    ax1.plot(param_counts, theoretical_memory, 'o-', label='Memoria Teórica', linewidth=2)
    if process is not None:
        ax1.plot(param_counts, memory_usage, 's-', label='Memoria Medida', linewidth=2)
    ax1.set_xlabel('Número de Parámetros')
    ax1.set_ylabel('Memoria (MB)')
    ax1.set_title('Memoria vs Número de Parámetros')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Gráfica 2: Memoria por componente
    hidden_sizes_plot = hidden_sizes
    weights_mem_list = [(input_size * h + h + h * output_size + output_size) * 8 / (1024*1024) 
                        for h in hidden_sizes_plot]
    activations_mem_list = [batch_size * (input_size + h + output_size) * 8 / (1024*1024) 
                           for h in hidden_sizes_plot]
    gradients_mem_list = [(input_size * h + h + h * output_size + output_size) * 8 / (1024*1024) 
                         for h in hidden_sizes_plot]
    
    ax2.plot(hidden_sizes_plot, weights_mem_list, 'o-', label='Pesos', linewidth=2)
    ax2.plot(hidden_sizes_plot, activations_mem_list, 's-', label='Activaciones', linewidth=2)
    ax2.plot(hidden_sizes_plot, gradients_mem_list, '^-', label='Gradientes', linewidth=2)
    ax2.set_xlabel('Hidden Size')
    ax2.set_ylabel('Memoria (MB)')
    ax2.set_title('Desglose de Memoria por Componente')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('experiments/results/memory_detailed.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("  Gráfica guardada en experiments/results/memory_detailed.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTO: ANÁLISIS DETALLADO DE MEMORIA")
    print("=" * 60 + "\n")
    
    experiment_memory_detailed()
    
    print("=" * 60)
    print("Experimento completado")
    print("=" * 60)

