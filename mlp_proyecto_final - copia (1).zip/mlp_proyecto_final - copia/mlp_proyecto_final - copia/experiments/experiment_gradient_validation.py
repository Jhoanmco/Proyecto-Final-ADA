"""
Experimento: Validación de gradientes con visualización
Genera gráficas mostrando la precisión de los gradientes
"""
import numpy as np
import matplotlib.pyplot as plt
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import numerical_gradient


def experiment_gradient_validation():
    """
    Valida gradientes y genera gráficas de comparación
    """
    print("Experimento: Validación de Gradientes")
    
    # Crear modelo pequeño para verificación rápida
    mlp = MLP(
        input_size=10,
        hidden_size=5,
        output_size=3,
        activation='sigmoid',
        loss='cross_entropy',
        learning_rate=0.001,
        seed=42
    )
    
    # Datos pequeños
    X = Matrix(np.random.randn(5, 10))
    y = Matrix(np.random.randint(0, 3, 5))
    
    # Forward y backward
    z1, a1, a2 = mlp.forward(X)
    dW1_analytical, db1_analytical, dW2_analytical, db2_analytical = mlp.backward(X, y, z1, a1, a2)
    
    # Gradientes numéricos
    dW1_numerical, db1_numerical, dW2_numerical, db2_numerical = numerical_gradient(mlp, X, y)
    
    # Calcular errores
    def compute_errors(analytical, numerical):
        diff = np.abs(analytical.data - numerical.data)
        rel_error = diff / (np.abs(analytical.data) + np.abs(numerical.data) + 1e-10)
        abs_error = diff / (np.abs(analytical.data) + 1e-10)
        return {
            'diff': diff,
            'rel_error': rel_error,
            'abs_error': abs_error,
            'max_rel': np.max(rel_error),
            'max_abs_norm': np.max(abs_error),
            'mean_rel': np.mean(rel_error),
            'mean_abs_norm': np.mean(abs_error)
        }
    
    errors_dw1 = compute_errors(dW1_analytical, dW1_numerical)
    errors_db1 = compute_errors(db1_analytical, db1_numerical)
    errors_dw2 = compute_errors(dW2_analytical, dW2_numerical)
    errors_db2 = compute_errors(db2_analytical, db2_numerical)
    
    print(f"  dW1 - Max error: {errors_dw1['max_abs_norm']:.2e}")
    print(f"  db1 - Max error: {errors_db1['max_abs_norm']:.2e}")
    print(f"  dW2 - Max error: {errors_dw2['max_abs_norm']:.2e}")
    print(f"  db2 - Max error: {errors_db2['max_abs_norm']:.2e}")
    
    # Gráficas de comparación
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    
    # dW1
    ax = axes[0, 0]
    analytical_flat = dW1_analytical.data.flatten()
    numerical_flat = dW1_numerical.data.flatten()
    ax.scatter(analytical_flat, numerical_flat, alpha=0.6, s=50)
    min_val = min(np.min(analytical_flat), np.min(numerical_flat))
    max_val = max(np.max(analytical_flat), np.max(numerical_flat))
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='y=x')
    ax.set_xlabel('Gradiente Analítico')
    ax.set_ylabel('Gradiente Numérico')
    ax.set_title(f'dW1 (Error max: {errors_dw1["max_abs_norm"]:.2e})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # db1
    ax = axes[0, 1]
    analytical_flat = db1_analytical.data.flatten()
    numerical_flat = db1_numerical.data.flatten()
    ax.scatter(analytical_flat, numerical_flat, alpha=0.6, s=50, color='green')
    min_val = min(np.min(analytical_flat), np.min(numerical_flat))
    max_val = max(np.max(analytical_flat), np.max(numerical_flat))
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='y=x')
    ax.set_xlabel('Gradiente Analítico')
    ax.set_ylabel('Gradiente Numérico')
    ax.set_title(f'db1 (Error max: {errors_db1["max_abs_norm"]:.2e})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # dW2
    ax = axes[1, 0]
    analytical_flat = dW2_analytical.data.flatten()
    numerical_flat = dW2_numerical.data.flatten()
    ax.scatter(analytical_flat, numerical_flat, alpha=0.6, s=50, color='orange')
    min_val = min(np.min(analytical_flat), np.min(numerical_flat))
    max_val = max(np.max(analytical_flat), np.max(numerical_flat))
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='y=x')
    ax.set_xlabel('Gradiente Analítico')
    ax.set_ylabel('Gradiente Numérico')
    ax.set_title(f'dW2 (Error max: {errors_dw2["max_abs_norm"]:.2e})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # db2
    ax = axes[1, 1]
    analytical_flat = db2_analytical.data.flatten()
    numerical_flat = db2_numerical.data.flatten()
    ax.scatter(analytical_flat, numerical_flat, alpha=0.6, s=50, color='purple')
    min_val = min(np.min(analytical_flat), np.min(numerical_flat))
    max_val = max(np.max(analytical_flat), np.max(numerical_flat))
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='y=x')
    ax.set_xlabel('Gradiente Analítico')
    ax.set_ylabel('Gradiente Numérico')
    ax.set_title(f'db2 (Error max: {errors_db2["max_abs_norm"]:.2e})')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.suptitle('Validación de Gradientes: Analítico vs Numérico', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.savefig('experiments/results/gradient_validation.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("  Gráfica guardada en experiments/results/gradient_validation.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTO: VALIDACIÓN DE GRADIENTES")
    print("=" * 60 + "\n")
    
    experiment_gradient_validation()
    
    print("=" * 60)
    print("Experimento completado")
    print("=" * 60)

