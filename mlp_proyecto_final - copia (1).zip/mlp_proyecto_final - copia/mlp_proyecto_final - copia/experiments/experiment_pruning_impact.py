"""
Experimento: Impacto de la poda en precisión y memoria
Demuestra el trade-off entre precisión y reducción de parámetros
"""
import numpy as np
import matplotlib.pyplot as plt
import sys
import os
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.data_structures import PruningHeap
from mlp_from_scratch.utils import generate_synthetic_data


def apply_pruning(mlp: MLP, pruning_ratio: float):
    """
    Aplica poda al modelo eliminando los pesos más pequeños
    
    Args:
        mlp: Modelo MLP
        pruning_ratio: Proporción de pesos a eliminar (0.0 a 1.0)
    """
    # Crear heap con todos los pesos
    heap = PruningHeap()
    
    # Insertar pesos de W1
    for i in range(mlp.W1.data.shape[0]):
        for j in range(mlp.W1.data.shape[1]):
            heap.insert(mlp.W1.data[i, j], 1, i, j)
    
    # Insertar pesos de W2
    for i in range(mlp.W2.data.shape[0]):
        for j in range(mlp.W2.data.shape[1]):
            heap.insert(mlp.W2.data[i, j], 2, i, j)
    
    # Calcular cuántos pesos eliminar
    total_weights = heap.size()
    n_to_prune = int(total_weights * pruning_ratio)
    
    # Obtener los pesos más pequeños
    pruned_weights = heap.get_top_k(n_to_prune)
    
    # Crear máscara de pesos a eliminar
    pruned_positions = set()
    for _, (layer, row, col) in pruned_weights:
        pruned_positions.add((layer, row, col))
    
    # Aplicar poda (poner a cero los pesos más pequeños)
    for layer, row, col in pruned_positions:
        if layer == 1:
            mlp.W1.data[row, col] = 0.0
        elif layer == 2:
            mlp.W2.data[row, col] = 0.0


def experiment_pruning_tradeoff():
    """
    Evalúa el trade-off entre precisión y reducción de parámetros mediante poda
    """
    print("Experimento: Trade-off Poda vs Precisión")
    
    # Generar datos
    X_train, y_train, X_test, y_test = generate_synthetic_data(
        n_samples=1000,
        n_features=50,
        n_classes=5,
        test_size=0.2
    )
    
    # Entrenar modelo base
    print("  Entrenando modelo base...")
    mlp_base = MLP(
        input_size=50,
        hidden_size=32,
        output_size=5,
        activation='relu',
        learning_rate=0.01,
        seed=42
    )
    
    mlp_base.train(X_train, y_train, epochs=100, batch_size=32, verbose=False)
    base_accuracy = mlp_base.evaluate(X_test, y_test)
    base_params = (mlp_base.W1.data.size + mlp_base.b1.data.size + 
                   mlp_base.W2.data.size + mlp_base.b2.data.size)
    base_nonzero = (np.count_nonzero(mlp_base.W1.data) + 
                   np.count_nonzero(mlp_base.W2.data))
    
    print(f"  Modelo base - Precisión: {base_accuracy:.4f}, Parámetros: {base_params}, No-cero: {base_nonzero}")
    
    # Probar diferentes niveles de poda
    pruning_ratios = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    accuracies = []
    param_counts = []
    nonzero_counts = []
    
    for ratio in pruning_ratios:
        # Crear copia del modelo entrenado
        mlp_pruned = MLP(
            input_size=50,
            hidden_size=32,
            output_size=5,
            activation='relu',
            learning_rate=0.01,
            seed=42
        )
        
        # Copiar pesos del modelo base
        mlp_pruned.W1 = Matrix(mlp_base.W1.data.copy())
        mlp_pruned.b1 = Matrix(mlp_base.b1.data.copy())
        mlp_pruned.W2 = Matrix(mlp_base.W2.data.copy())
        mlp_pruned.b2 = Matrix(mlp_base.b2.data.copy())
        
        # Aplicar poda
        apply_pruning(mlp_pruned, ratio)
        
        # Evaluar
        accuracy = mlp_pruned.evaluate(X_test, y_test)
        params = (mlp_pruned.W1.data.size + mlp_pruned.b1.data.size + 
                 mlp_pruned.W2.data.size + mlp_pruned.b2.data.size)
        nonzero = (np.count_nonzero(mlp_pruned.W1.data) + 
                  np.count_nonzero(mlp_pruned.W2.data))
        
        accuracies.append(accuracy)
        param_counts.append(params)
        nonzero_counts.append(nonzero)
        
        print(f"  Poda {ratio*100:.0f}% - Precisión: {accuracy:.4f}, No-cero: {nonzero}")
    
    # Gráficas
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Gráfica 1: Precisión vs Ratio de poda
    ax1.plot([r*100 for r in pruning_ratios], [a*100 for a in accuracies], 'o-', linewidth=2, markersize=8)
    ax1.axhline(y=base_accuracy*100, color='r', linestyle='--', label='Base (sin poda)')
    ax1.set_xlabel('Ratio de Poda (%)')
    ax1.set_ylabel('Precisión (%)')
    ax1.set_title('Impacto de la Poda en la Precisión')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    ax1.set_ylim([0, 105])
    
    # Gráfica 2: Parámetros no-cero vs Precisión
    ax2.plot(nonzero_counts, [a*100 for a in accuracies], 's-', linewidth=2, markersize=8, color='green')
    ax2.set_xlabel('Número de Parámetros No-Cero')
    ax2.set_ylabel('Precisión (%)')
    ax2.set_title('Trade-off: Parámetros vs Precisión')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('experiments/results/pruning_tradeoff.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print("  Gráfica guardada en experiments/results/pruning_tradeoff.png\n")


if __name__ == "__main__":
    os.makedirs('experiments/results', exist_ok=True)
    
    print("=" * 60)
    print("EXPERIMENTO: IMPACTO DE LA PODA")
    print("=" * 60 + "\n")
    
    experiment_pruning_tradeoff()
    
    print("=" * 60)
    print("Experimento completado")
    print("=" * 60)

