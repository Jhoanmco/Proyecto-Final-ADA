# Proyecto Final: MLP desde Cero con Análisis Algorítmico

**Análisis y Diseño de Algoritmos 1**

Implementación completa de un Perceptrón Multicapa (MLP) desde cero, incluyendo análisis de complejidad temporal y espacial, estructuras de datos eficientes, y comparaciones con algoritmos baseline.

## Estructura del Proyecto

```
mlp_proyecto_final/
├── mlp_from_scratch/          # Código fuente principal
│   ├── __init__.py
│   ├── matrix.py              # Operaciones matriciales con análisis de complejidad
│   ├── activations.py         # Funciones de activación
│   ├── losses.py              # Funciones de pérdida
│   ├── mlp.py                 # Implementación del MLP (forward/backprop/SGD)
│   ├── selection.py           # Algoritmos de selección (Quickselect, top-k, etc.)
│   ├── data_structures.py     # Estructuras de datos (cola, hash, heap, BST)
│   ├── baselines.py           # Implementaciones baseline (k-NN, sorting)
│   └── utils.py               # Utilidades (verificación de gradientes, carga de datos)
├── tests/                     # Pruebas unitarias
│   ├── test_mlp.py
│   └── test_selection.py
├── experiments/               # Scripts de experimentos
│   ├── experiment_ra1.py      # Fase 1: Escalado con B, h, E
│   ├── experiment_ra2.py      # Fase 2: Algoritmos de selección
│   ├── experiment_ra3.py      # Fase 3: Estructuras de datos
│   ├── experiment_phase4.py   # Fase 4: Comparación con baselines
│   └── results/              # Gráficas generadas
├── run_experiments.py         # Script principal para ejecutar todos los experimentos
├── run_tests.py               # Script para ejecutar pruebas
├── requirements.txt           # Dependencias
└── README.md                  # Este archivo
```

## Instalación

1. Clonar o descargar el repositorio
2. Instalar dependencias:

```bash
pip install -r requirements.txt
```

## Uso Rápido

### Entrenar un MLP

```python
from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import generate_synthetic_data

# Generar datos
X_train, y_train, X_test, y_test = generate_synthetic_data(
    n_samples=1000, n_features=784, n_classes=10
)

# Crear y entrenar modelo
mlp = MLP(input_size=784, hidden_size=128, output_size=10, learning_rate=0.01)
mlp.train(X_train, y_train, epochs=50, batch_size=32)

# Evaluar
accuracy = mlp.evaluate(X_test, y_test)
print(f"Precisión: {accuracy:.4f}")
```

### Ejecutar Pruebas

```bash
python run_tests.py
```

### Ejecutar Experimentos

```bash
python run_experiments.py
```

O ejecutar experimentos individuales:

```bash
python experiments/experiment_ra1.py
python experiments/experiment_ra2.py
python experiments/experiment_ra3.py
python experiments/experiment_phase4.py
```

## Análisis de Complejidad

### MLP - Forward Propagation
- **Complejidad temporal**: O(B × (n×h + h×c))
  - B = batch_size, n = input_size, h = hidden_size, c = output_size
- **Complejidad espacial**: O(B × (n + h + c))

### MLP - Backward Propagation
- **Complejidad temporal**: O(B × (n×h + h×c))
- **Complejidad espacial**: O(n×h + h×c) para gradientes

### MLP - Entrenamiento Completo
- **Complejidad temporal**: O(E × N × (n×h + h×c))
  - E = épocas, N = número total de muestras
- **Complejidad espacial**: O(B × (n + h + c)) durante entrenamiento

### Quickselect (Mediana)
- **Complejidad temporal promedio**: O(n)
- **Complejidad temporal peor caso**: O(n²)
- **Análisis de recurrencia**: T(n) = T(n/2) + O(n) en promedio

### Top-k con Heap
- **Complejidad temporal**: O(n log k) cuando k << n
- **Ventaja sobre sort**: O(n log k) vs O(n log n)

### Heapsort
- **Complejidad temporal**: O(n log n) en todos los casos
- **Análisis**: T(n) = 2T(n/2) + O(log n) para heapify

### Quicksort
- **Complejidad temporal promedio**: O(n log n)
- **Complejidad temporal peor caso**: O(n²)
- **Análisis**: T(n) = 2T(n/2) + O(n) en promedio

## Características Implementadas

### Fase 1 (RA1)
- ✅ MLP básico con 1 capa oculta
- ✅ Forward propagation
- ✅ Backward propagation
- ✅ SGD (Stochastic Gradient Descent)
- ✅ Análisis de complejidad temporal/espacial
- ✅ Experimentos de escalado (B, h, E)

### Fase 2 (RA2)
- ✅ Quickselect para mediana
- ✅ Top-k con heap vs sort
- ✅ Hard negative mining
- ✅ Heapsort
- ✅ Quicksort
- ✅ Análisis con recurrencias y Método Maestro

### Fase 3 (RA3)
- ✅ Cola de lotes (BatchQueue)
- ✅ Hash de pérdidas (LossHash)
- ✅ Heap para poda (PruningHeap)
- ✅ BST para poda (PruningBST)
- ✅ Evaluación de impacto en tiempo y memoria

### Fase 4
- ✅ k-NN baseline
- ✅ Comparación MLP vs k-NN
- ✅ Comparación de algoritmos de ordenamiento
- ✅ Verificación de gradientes

## Verificación de Gradientes

El proyecto incluye verificación numérica de gradientes para asegurar la correcta implementación del backpropagation:

```python
from mlp_from_scratch.utils import gradient_check
from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix

mlp = MLP(input_size=10, hidden_size=5, output_size=2)
X = Matrix(np.random.randn(10, 10))
y = Matrix(np.random.randint(0, 2, 10))

is_correct = gradient_check(mlp, X, y, tolerance=1e-5)
```

## Resultados Obtenidos

- ✅ **Precisión 91.80% en MNIST** (5000 muestras) - Supera el 85% requerido
- ✅ **Precisión 97.75% - 100% en datos sintéticos estructurados**
- ✅ **Verificación de gradientes**: Error máximo 4.46e-06 (muy por debajo de 1e-5)
- ✅ **Complejidad**: Todas las derivaciones Big-O correctas y consistentes con mediciones
- ✅ **Estructuras de datos**: Mejoras observables documentadas
- ✅ **Análisis de poda**: Trade-off precisión vs parámetros documentado

## Gráficas Generadas

Los experimentos generan **15 gráficas** en `experiments/results/`:

### Fase 1 (RA1) - Escalado
- `ra1_batch_size.png`: Tiempo vs Batch Size
- `ra1_hidden_size.png`: Tiempo vs Hidden Size
- `ra1_epochs.png`: Tiempo vs Número de Épocas
- `ra1_memory.png`: Memoria vs Parámetros

### Fase 2 (RA2) - Algoritmos de Selección
- `ra2_quickselect_vs_sort.png`: Comparación Quickselect vs Sort
- `ra2_topk_heap_vs_sort.png`: Comparación Top-k Heap vs Sort
- `ra2_heapsort_vs_quicksort.png`: Comparación de algoritmos de ordenamiento
- `ra2_hard_mining.png`: Hard Mining Heap vs Sort

### Fase 3 (RA3) - Estructuras de Datos
- `ra3_batch_queue.png`: Rendimiento de Batch Queue
- `ra3_loss_hash.png`: Rendimiento de Loss Hash
- `ra3_pruning_heap_vs_bst.png`: Comparación Heap vs BST para poda

### Fase 4 - Baselines
- `phase4_mlp_vs_knn.png`: Comparación MLP vs k-NN
- `phase4_sorting_comparison.png`: Comparación final de ordenamiento

### Validaciones Adicionales
- `gradient_validation.png`: Validación de gradientes (analítico vs numérico)
- `memory_detailed.png`: Análisis detallado de memoria
- `pruning_tradeoff.png`: Trade-off de poda (precisión vs parámetros)

## Notas Técnicas

- **Sin frameworks de alto nivel**: Solo se usa NumPy para operaciones matriciales básicas
- **Código modular**: Cada componente está separado y es testeable
- **Análisis completo**: Todas las funciones incluyen análisis de complejidad en sus docstrings
- **Pruebas unitarias**: Cobertura de funcionalidades principales
- **Datos sintéticos**: Generación de datos para pruebas cuando MNIST no está disponible

## Autor

Proyecto final para el curso de Análisis y Diseño de Algoritmos 1.

## Licencia

Este proyecto es parte de un trabajo académico.

