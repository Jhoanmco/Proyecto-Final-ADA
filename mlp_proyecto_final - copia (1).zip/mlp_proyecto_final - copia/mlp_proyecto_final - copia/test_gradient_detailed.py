"""
Prueba detallada de verificación de gradientes con análisis de errores
"""
import numpy as np
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from mlp_from_scratch.mlp import MLP
from mlp_from_scratch.matrix import Matrix
from mlp_from_scratch.utils import numerical_gradient

# Modelo pequeño
mlp = MLP(input_size=5, hidden_size=3, output_size=2, seed=42)
X = Matrix(np.random.randn(3, 5))
y = Matrix(np.random.randint(0, 2, 3))

# Forward
z1, a1, a2 = mlp.forward(X)

# Gradientes analíticos
dW1_analytical, db1_analytical, dW2_analytical, db2_analytical = mlp.backward(X, y, z1, a1, a2)

# Gradientes numéricos
dW1_numerical, db1_numerical, dW2_numerical, db2_numerical = numerical_gradient(mlp, X, y)

print("Comparacion detallada:")
print("\n=== dW1 ===")
print(f"Analitico shape: {dW1_analytical.shape}")
print(f"Numerico shape: {dW1_numerical.shape}")
print(f"Analitico:\n{dW1_analytical.data}")
print(f"Numerico:\n{dW1_numerical.data}")
print(f"Diferencia absoluta:\n{np.abs(dW1_analytical.data - dW1_numerical.data)}")
print(f"Diferencia relativa:\n{np.abs(dW1_analytical.data - dW1_numerical.data) / (np.abs(dW1_analytical.data) + 1e-10)}")

print("\n=== dW2 ===")
print(f"Analitico:\n{dW2_analytical.data}")
print(f"Numerico:\n{dW2_numerical.data}")
print(f"Diferencia absoluta:\n{np.abs(dW2_analytical.data - dW2_numerical.data)}")
print(f"Diferencia relativa:\n{np.abs(dW2_analytical.data - dW2_numerical.data) / (np.abs(dW2_analytical.data) + 1e-10)}")

# Calcular error usando diferentes métricas
def max_relative_error(analytical, numerical):
    numerator = np.abs(analytical.data - numerical.data)
    denominator = np.abs(analytical.data) + np.abs(numerical.data) + 1e-10
    return np.max(numerator / denominator)

def mean_relative_error(analytical, numerical):
    numerator = np.abs(analytical.data - numerical.data)
    denominator = np.abs(analytical.data) + np.abs(numerical.data) + 1e-10
    return np.mean(numerator / denominator)

def max_absolute_error(analytical, numerical):
    return np.max(np.abs(analytical.data - numerical.data))

print("\n=== Errores ===")
print(f"dW1 - Max error relativo: {max_relative_error(dW1_analytical, dW1_numerical):.2e}")
print(f"dW1 - Mean error relativo: {mean_relative_error(dW1_analytical, dW1_numerical):.2e}")
print(f"dW1 - Max error absoluto: {max_absolute_error(dW1_analytical, dW1_numerical):.2e}")

print(f"dW2 - Max error relativo: {max_relative_error(dW2_analytical, dW2_numerical):.2e}")
print(f"dW2 - Mean error relativo: {mean_relative_error(dW2_analytical, dW2_numerical):.2e}")
print(f"dW2 - Max error absoluto: {max_absolute_error(dW2_analytical, dW2_numerical):.2e}")

